# Claude Code Directions — CourseBuilder Fixes
# Date: April 4, 2026
# Push to main, no PR, direct merge

## IMPORTANT RULES
- Push directly to main. No feature branches. No PRs.
- After every file edit, verify with `sed -n 'X,Yp'` or `grep` — do NOT summarize.
- Do NOT touch any files not listed below.

---

## FILES TO REPLACE (4 files)
All in `client/src/components/CourseBuilder/`:

### 1. constants.js — REPLACE ENTIRE FILE
Changes:
- Navy hex fixed: `#284157` (was `#34495E`)
- navyLight: `#3A5A72` (was `#4A6278`)
- 3 new block types added to BLOCK_TYPES array (now 20 total):
  - `callout` (category: content, icon: ℹ️, color: #3B82F6)
  - `keyTakeaway` (category: content, icon: 🔑, color: C.gold)
  - `fillInBlank` (category: assessment, icon: ✏️, color: C.amber)
- 3 new entries in BLOCK_DEFAULTS:
  - `callout: { calloutType: "info", title: "", content: "", items: [] }`
  - `keyTakeaway: { title: "", content: "", points: [] }`
  - `fillInBlank: { instructions: "", sentence: "", blanks: [{ answer: "", hint: "" }] }`
- `fillInBlank` added to KNOWLEDGE_CHECK_TYPES array
- `callout` and `keyTakeaway` added to CONTENT_TYPES array
- Comment updated: "20 Total" (was "17 Total")

VERIFY after replacing:
```
grep 'navy:' client/src/components/CourseBuilder/constants.js
# Must show: navy: "#284157"

grep -c 'type:' client/src/components/CourseBuilder/constants.js
# Should show count reflecting 20 block types

grep 'fillInBlank' client/src/components/CourseBuilder/constants.js
# Must return matches
```

### 2. ReferencesManager.jsx — REPLACE ENTIRE FILE
Change: Line 2 import changed from `{ useState }` to `{ useState, useEffect }`
(useEffect was used on line 17 but never imported — runtime crash)

VERIFY:
```
sed -n '2p' client/src/components/CourseBuilder/ReferencesManager.jsx
# Must show: import { useState, useEffect } from "react";
```

### 3. CourseBuilder.jsx — REPLACE ENTIRE FILE
Changes:
- Font Awesome CDN link removed (line 245 in old file)
- All 6 `<i className="fas fa-*">` nav icons replaced with Lucide React components
- Import line updated: added BookOpen, Users, BarChart3, Mail, BadgeCheck, Home to lucide-react import

VERIFY:
```
grep -c 'fas fa-' client/src/components/CourseBuilder/CourseBuilder.jsx
# Must return 0

grep 'font-awesome' client/src/components/CourseBuilder/CourseBuilder.jsx
# Must return nothing

grep 'BookOpen' client/src/components/CourseBuilder/CourseBuilder.jsx
# Must return matches
```

### 4. ContentEditor.jsx — REPLACE ENTIRE FILE
Changes:
- Split edit/preview view: when a block is open for editing, left side shows edit form, right side shows "👁 Student View" with live BlockPreview
- Preview toggle button (Eye/EyeOff) in toolbar
- Callout syntax hint bar when preview is on
- Block duplicate button (⧉) added to block toolbar
- Imports BlockPreview from ./BlockPreview
- Block count in empty state now shows `{BLOCK_TYPES.length}` (dynamic, was hardcoded "17")

VERIFY:
```
grep 'BlockPreview' client/src/components/CourseBuilder/ContentEditor.jsx
# Must show import and usage

grep 'showPreview' client/src/components/CourseBuilder/ContentEditor.jsx
# Must return multiple matches (state, toggle, conditional rendering)

grep 'duplicateBlock' client/src/components/CourseBuilder/ContentEditor.jsx
# Must return matches
```

---

## NEW FILE TO ADD (1 file)

### 5. BlockPreview.jsx — CREATE NEW FILE
Location: `client/src/components/CourseBuilder/BlockPreview.jsx`
Size: ~455 lines

This is a new file. It renders all 20 block types as students see them.
- Imports `parseAuthoringSyntax`, `SlimCalloutBlock`, `SlimAccordion`, `SlimSectionDivider` from `../CourseViewerPatch`
- Text and imageText blocks run content through `parseAuthoringSyntax()` so `{{callout:hipaa}}` and `{{alert:ethics}}` render as styled pills
- MC questions are clickable with answer checking
- Flashcards flip, scenario trees navigate, fill-in-blank validates
- Handles both `{text, isCorrect}` and `[String] + correctAnswer` option formats

VERIFY:
```
ls -la client/src/components/CourseBuilder/BlockPreview.jsx
# Must exist

grep 'parseAuthoringSyntax' client/src/components/CourseBuilder/BlockPreview.jsx
# Must return matches

grep 'fillInBlank\|keyTakeaway\|callout' client/src/components/CourseBuilder/BlockPreview.jsx
# Must return matches for all 3 new block types
```

---

## DEPENDENCY CHECK
BlockPreview.jsx imports from `../CourseViewerPatch`. Verify it exists:
```
ls -la client/src/components/CourseViewerPatch.jsx
# Must exist (already on main)
```

---

## DO NOT TOUCH
- BlockEditor.jsx
- AIGenerator.jsx
- ExamGenerator.jsx
- ImportTab.jsx
- NarrationPanel.jsx
- NarrationTab.jsx
- CloudinaryUploader.jsx
- BlockPicker.jsx
- BlockTypeCatalog.jsx
- InsertBar.jsx
- styles.js
- utils.js
- index.js
- Any file outside CourseBuilder/

---

## AFTER ALL CHANGES
```
# Count files in CourseBuilder folder — should be 19 (18 original + BlockPreview.jsx)
ls client/src/components/CourseBuilder/ | wc -l

# List all files to confirm
ls -la client/src/components/CourseBuilder/

# Commit and push to main
git add client/src/components/CourseBuilder/
git commit -m "fix: CourseBuilder - navy color, useEffect crash, FA removal, split preview, 3 new block types"
git push origin main
```

## KNOWN REMAINING ISSUES (do NOT fix in this session)
- Bug #3: MC/multiSelect defaults still use {text, isCorrect} format (needs coordinated BlockEditor rewrite)
- Bug #4: AIGenerator still uses fake setTimeout (needs backend AI proxy endpoints)
- Architecture: still uses modules[].blocks[] internally (plan calls for sections[].contentBlocks[])
- No useReducer/context, no undo/redo, no autosave
