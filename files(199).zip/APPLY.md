# Fix: PUT /api/files/resources/:id returns 500 (supplements won't save in the React builder)

## Cause
`server/src/routes/fileUpload.js` imported the InteractiveCourse model as a DEFAULT import:
    import InteractiveCourse from '../models/InteractiveCourse.js';
But that model's default export is an OBJECT `{ Course, CourseProgress, ContentInteraction }`,
not the model. So `InteractiveCourse.findByIdAndUpdate(...)` was `undefined(...)` → threw →
500 on every resources save. (Uploads/browse worked because they don't touch the model.)

This is the call the React builder's SupplementsManager uses, so saving supplements there
failed. The course EDITOR panel (PR #436) is unaffected — it saves via the editor's
"Save All Changes" → PUT /api/admin/courses/:id, which imports the model correctly.

## Fix — ONE line in server/src/routes/fileUpload.js
    - import InteractiveCourse from '../models/InteractiveCourse.js';
    + import { Course as InteractiveCourse } from '../models/InteractiveCourse.js';
(Matches how adminCourses.js imports it.) Verified: parses; diff is 1 line.

## Apply via Claude Code (feature branch → PR → MERGE)
```
Fix the 500 on PUT /api/files/resources/:id. Feature branch → PR → MERGE. Follow CLAUDE.md.
Touch ONLY server/src/routes/fileUpload.js. One-line change:

  Replace:  import InteractiveCourse from '../models/InteractiveCourse.js';
  With:     import { Course as InteractiveCourse } from '../models/InteractiveCourse.js';

Reason: the model's default export is { Course, ... }, so the default import made
InteractiveCourse.findByIdAndUpdate undefined → 500. The named Course export is the model.

Verify:
  grep -n "import { Course as InteractiveCourse }" server/src/routes/fileUpload.js   # 1 match
  node --check server/src/routes/fileUpload.js
After merge, confirm on main:
  git fetch origin
  git show origin/main:server/src/routes/fileUpload.js | grep -c "{ Course as InteractiveCourse }"  # MUST be 1
Show me the diff and grep. Open PR → merge → confirm grep=1.
```

## Separately (NOT in this fix) — possible same-bug elsewhere, please check
These also default-import the model; verify whether they use it as a model directly
(bug) or as `InteractiveCourse.Course.x` (fine). Not touched here per Prime Directive:
- server/src/routes/partners.js
- server/src/middleware/quotaEnforcement.js
- server/src/scripts/bulkRegenerateBadCerts.js
- server/src/scripts/patchMissingSlugs.js

## After this deploys
The React builder's Supplements tab will save. The editor panel already saves via its own
button. Both write course.resources[]; confirm by adding a supplement, saving, reloading.
