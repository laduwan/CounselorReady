# CC Prompt — Certificate Rebuild (SHIP IT)

**Branch:** `ke/cert-rebuild` — commit on this branch and open a PR to `main`. **Do not push to main.**

This is a coordinated 5-part change. All parts ship together — they are interdependent. Apply in this order. Do NOT reformat any file beyond the diff described.

---

## PART 1 — Drop in three image assets

Upload these files (provided in the `cert-rebuild/` deliverable archive) to `server/src/templates/`. If the directory does not exist, create it.

```
server/src/templates/gaitp-logo.png     (PNG, RGBA, ~13.8 KB,  MD5 2b7df06f72c886193a55798ead8af0e2)
server/src/templates/nbcc-seal.jpg      (JPEG, ~11.5 KB,        MD5 a815d1e664d20e90f80435ddcb7cb75c)
server/src/templates/signature.png      (PNG, RGBA, ~10.0 KB,   MD5 b7ac8744278101e9d942b36b2412dbd4)
```

If older filenames exist in this directory (e.g. `logo.jpg`, `nbcc-acep-logo.jpg`, `cr-watermark.png`), leave them alone — the new generator references only the new filenames above.

**Verify:**
```bash
md5sum server/src/templates/gaitp-logo.png server/src/templates/nbcc-seal.jpg server/src/templates/signature.png
```
Expected MD5s match the values above.

---

## PART 2 — Replace `server/src/utils/certificate.js`

Replace the entire contents of `server/src/utils/certificate.js` with the file provided in the deliverable archive (`cert-rebuild/certificate.js`).

**Drop in verbatim. Do not edit, reformat, or "improve" the file.** The function signature is preserved (`generateCertificate({ holderName, courseName, completionDate, ceHours, certificateNumber, ... })`) so existing call sites continue to work without changes.

**Verify:**
```bash
wc -l server/src/utils/certificate.js
# Expected: ~365 lines

md5sum server/src/utils/certificate.js
# Expected: e7d240a7aa2c8ed218409896093eb8cb

grep -c "^export " server/src/utils/certificate.js
# Expected: 4 named exports (generateCertificate, generateCertificateNumber, generateSignedCertificateUrl, extractPublicIdFromUrl)
```

---

## PART 3 — Add `certificateName` to the User profile schema

In `server/src/models/User.js`, find the `profile` subdocument schema. Add a new optional field `certificateName` next to `firstName` / `lastName`. The field is trimmed and capped at 200 chars. **No default value.**

Find a block like:
```js
profile: {
  firstName: { type: String, trim: true },
  lastName:  { type: String, trim: true },
  // ...other profile fields
}
```

Add `certificateName` immediately after lastName:
```js
profile: {
  firstName:       { type: String, trim: true },
  lastName:        { type: String, trim: true },
  certificateName: { type: String, trim: true, maxLength: 200 },
  // ...other profile fields unchanged
}
```

Do NOT touch any other profile field. Do NOT add a default. Do NOT add `required: true`. Empty value means "fall back to firstName + lastName" — that's intentional.

**Verify:**
```bash
grep -n "certificateName" server/src/models/User.js
# Expected: one match, inside profile {} block
```

---

## PART 4 — Patch both certificate call sites

There are exactly two call sites that compute the recipient name. Both must be updated identically so the cert prints `profile.certificateName` when set, falling back to the existing logic when empty.

### 4a. `server/src/routes/interactiveCourseRoutes.js`

Find this line (around line 908):
```js
const userName = `${(user.profile?.firstName || '')} ${(user.profile?.lastName || '')}`.trim() || user.email;
```

Replace with:
```js
const userName =
  (user.profile?.certificateName?.trim()) ||
  `${(user.profile?.firstName || '')} ${(user.profile?.lastName || '')}`.trim() ||
  user.email;
```

### 4b. `server/src/routes/admin.js`

Find these lines (around line 87):
```js
const userName =
  `${user.profile?.firstName || ''} ${user.profile?.lastName || ''}`.trim() || user.email || 'Unknown';
```

Replace with:
```js
const userName =
  (user.profile?.certificateName?.trim()) ||
  `${user.profile?.firstName || ''} ${user.profile?.lastName || ''}`.trim() ||
  user.email ||
  'Unknown';
```

Also update the `.populate(...)` call in admin.js (the line that currently selects `'profile.firstName profile.lastName email'`) to include `certificateName`:
```js
.populate('userId', 'profile.firstName profile.lastName profile.certificateName email')
```

That is the only change in admin.js. The rest of the regenerate handler is unchanged.

**Verify:**
```bash
grep -B1 -A4 "certificateName" server/src/routes/interactiveCourseRoutes.js
grep -B1 -A4 "certificateName" server/src/routes/admin.js
# Expected: both files show the new fallback chain
```

---

## PART 5 — Surface `certificateName` on the profile/settings page

Find the profile/settings page where a logged-in user edits their `firstName` / `lastName`. Likely candidates:
- `client/public/settings.html`
- `client/src/pages/Profile.jsx`
- `client/src/pages/Settings.jsx`

Run to find:
```bash
grep -rln "profile.firstName\|profile\['firstName'\]" client/public client/src 2>/dev/null
```

In whichever file edits the profile name fields, add a new editable text input for `certificateName` directly below the lastName input. Style it to match the surrounding form. Use this exact helper text below the field:

> "Name as it should appear on your CE certificates. Match your license name to ensure board acceptance. Leave blank to use your first and last name."

Wire it up to:
- **Read from:** `user.profile.certificateName` (may be undefined → show empty)
- **Write to:** the same PATCH/PUT endpoint that already saves `profile.firstName` (likely `/api/users/profile` or `/api/auth/me`)
- **Field key in request body:** `certificateName` under the `profile` object

Also verify the corresponding backend update route accepts the new field. If the route uses an explicit allow-list (e.g., `_.pick(req.body.profile, ['firstName', 'lastName', ...])`), add `'certificateName'` to that array. If the route accepts the whole `profile` object, no change needed — but verify Mongoose isn't running in strict-mode-throw on unknown fields.

**Verify:**
```bash
grep -rn "certificateName" client/
# Expected: at least one match in the profile/settings page
```

---

## VERIFICATION — paste output in PR description

Run all of these. Paste raw output in the PR.

```bash
# 1. Image assets present with correct checksums
md5sum server/src/templates/gaitp-logo.png server/src/templates/nbcc-seal.jpg server/src/templates/signature.png

# 2. Cert generator file
wc -l server/src/utils/certificate.js
md5sum server/src/utils/certificate.js

# 3. Schema field added
grep -A1 "certificateName" server/src/models/User.js

# 4. Both call sites updated
grep -B1 -A4 "certificateName" server/src/routes/interactiveCourseRoutes.js
grep -B1 -A4 "certificateName" server/src/routes/admin.js

# 5. Profile page wired
grep -rn "certificateName" client/
```

**Expected file checksums:**
```
e7d240a7aa2c8ed218409896093eb8cb  certificate.js
2b7df06f72c886193a55798ead8af0e2  gaitp-logo.png
a815d1e664d20e90f80435ddcb7cb75c  nbcc-seal.jpg
b7ac8744278101e9d942b36b2412dbd4  signature.png
```

After Render redeploys the preview environment:

1. Generate a cert (complete a course as a test user OR use the admin regenerate endpoint on an existing cert)
2. Download the PDF
3. Visually confirm:
   - Burgundy outer border with gold diamond at each corner
   - Hunter green inner border
   - Provider name "Ga Integrated Therapeutic Perspectives, LLC" in bold-italic hunter green at top
   - "NBCC Approved Continuing Education Provider · ACEP #7760" credential line in burgundy italic below it
   - "Certificate of Completion" headline in burgundy italic
   - **GAITP logo visible** as watermark behind body content (burgundy/hunter green mark, ~12% opacity)
   - Recipient name in navy bold with heavy gold underline
   - "Instructor: Kejuiana Johnson..." line in **bold navy** (visibly blue)
   - "Asynchronous" line in burgundy italic
   - "Learning Objectives" header in hunter green italic, followed by numbered list
   - Bottom row: Course Approval block (left) | NBCC seal + gold serial bar (center) | signature + name + "Authorized Signature" label (right)
   - **Hunter hairlines** under "Course Approval" and under signature aligned at the same Y
   - NBCC compliance disclaimer paragraph in small grey at bottom
   - "Verify at counselorready.com/verify/{code}" at very bottom

Then test the new field:

4. Log in as a test user
5. Go to profile/settings, set `certificateName` to something distinctive like "Dr. Jane M. Doe, LPC, NCC"
6. Save profile
7. Regenerate cert (admin route OR complete a fresh course)
8. Download cert and confirm the recipient name matches what was typed in `certificateName`, NOT firstName + lastName

Post screenshots of the regenerated cert in the PR.

---

## SCOPE GUARDRAILS

- Do **NOT** modify `server/src/services/certificateService.js` — that's dead code, separate cleanup later.
- Do **NOT** touch the migration cert path (`server/src/routes/migration.js`).
- Do **NOT** add new dependencies. PDFKit + Cloudinary + fs/path are already used.
- Do **NOT** change the function signature of `generateCertificate()` — the new file preserves it exactly.
- Do **NOT** modify the Cloudinary upload code in either route handler — only the `userName` computation changes.
- Do **NOT** change the certificate number format.
- Do **NOT** force-push, do **NOT** rebase main into the branch, do **NOT** merge before review.

If anything is ambiguous, **STOP and ask** before improvising. Better a question than a wrong commit.
