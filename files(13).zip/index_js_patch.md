# Patch: server/src/index.js — Mount adminRewards Routes

Adds the new `adminRewards.js` route file to the Express app and the route manifest.

---

## Step 1 — Add the import

In the imports block at the top of `index.js`, add:

```js
import adminRewardsRoutes from './routes/adminRewards.js';
```

Place it near the other admin route imports (like `adminUsers`).

---

## Step 2 — Mount the routes

Find the route mounting section (where `app.use('/api/...', someRoutes)` calls live). Add this line:

```js
app.use('/api/admin/rewards', adminRewardsRoutes);
```

**ORDER MATTERS:** Mount this **after** the generic `admin.js` mount (`app.use('/api/admin', adminRoutes)`) to avoid path conflicts with any `/:param` catch-all routes inside admin.js. This matches the May 1 pattern documented in CLAUDE.md for `adminUsers`.

So the order should be:

```js
app.use('/api/admin', adminRoutes);          // existing — generic admin
app.use('/api/admin/users', adminUsersRoutes); // existing — May 1 fix
app.use('/api/admin/rewards', adminRewardsRoutes); // ← NEW Day 3
```

---

## Step 3 — Add to REQUIRED_ROUTES manifest

If `index.js` has a `REQUIRED_ROUTES` array (per `routeManifest.js` pattern), add the entry. Look for an array like:

```js
const REQUIRED_ROUTES = [
  // ...
  { name: 'adminUsers', mount: '/api/admin/users', file: './routes/adminUsers.js' },
  // ...
];
```

Add this entry alongside it:

```js
{ name: 'adminRewards', mount: '/api/admin/rewards', file: './routes/adminRewards.js' },
```

If the manifest lives in a separate file (`server/src/routeManifest.js`), update that file instead.

---

## Verify

After patches land, in Render shell or local:

```bash
node --check server/src/index.js
# Expect: silent

grep -n "adminRewards" server/src/index.js
# Expect: 2-3 lines (import + mount + optional manifest)
```

Smoke test from local terminal once deployed:

```bash
TOKEN="paste_admin_token_here"

# Should return JSON with pending/fulfilled/cancelled counts
curl -s -H "Authorization: Bearer $TOKEN" \
  https://api.counselorready.com/api/admin/rewards/stats

# Should return { redemptions: [], count: 0, filter: ... } on a fresh deploy
curl -s -H "Authorization: Bearer $TOKEN" \
  https://api.counselorready.com/api/admin/rewards/queue
```

If you get 401 — token isn't admin.
If you get 404 — mount didn't take, or order conflict with admin.js.
If you get 500 — check Render logs for `[ADMIN REWARDS]` errors.
