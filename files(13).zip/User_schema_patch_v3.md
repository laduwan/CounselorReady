# Schema Patch v3 — Day 3 Redemption Enums

**File to modify:** `server/src/models/User.js`
**Why:** Ensure `careCredits.transactions[].type` enum permits all current and Day 3 transaction types. Day 2.5c added `course_evaluation` to the service, which may not be in the deployed enum. Day 3 adds two redemption types.

---

## What to do

Find the `careCredits.transactions` array definition. Look for the `type` field with an `enum` constraint.

**If the enum currently is strict (a literal `enum: [...]` array)** — replace it with this expanded enum that includes every type used by the rewards service:

```js
type: {
  type: String,
  enum: [
    'reflection_submitted',
    'course_completion',
    'certificate_earned',
    'course_review',
    'course_evaluation',
    'referral_signup',
    'referral_paid',
    'referral_retention_bonus',
    'social_share',
    'streak_7day',
    'streak_30day',
    'redemption_stripe_credit',
    'redemption_giftcard',
    'admin_adjustment'
  ],
  default: 'admin_adjustment',
  required: true
},
```

**If the type field has no enum constraint** (just `type: { type: String }`) — leave it alone. No change needed.

**If you can't find the careCredits subdoc structure** — paste the careCredits block from User.js and I'll write a precise str_replace.

---

## Verifying

After deploying, in Render shell:

```js
let _conn = await require('mongoose').connect(process.env.MONGODB_URI); void 0;
const User = require('./src/models/User').default;

// Check enum includes new types
const path = User.schema.path('careCredits.transactions');
console.log(path.schema.path('type').enumValues);
// Expect: array containing 'course_evaluation', 'redemption_stripe_credit', 'redemption_giftcard'
process.exit(0);
```

If the array contains all 14 values listed above, schema is good. If shorter, something didn't merge.

---

## NOT needed

- No DB migration. Existing transactions stay as-is.
- No backfill. New enum applies to new writes only.
