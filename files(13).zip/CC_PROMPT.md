# Claude Code Prompt — Day 3 Deployment

**Repo:** github.com/laduwan/CounselorReady
**Branch:** `day3-rewards-redemption` (create from main)
**Push target:** main (PR optional — Ke pushes direct per workflow)

---

## CRITICAL RULES (per CLAUDE.md)

1. **`server/src/routes/interactiveCourseRoutes.js` is sacred.** Day 3 does NOT touch it. If your patch plan includes that file, STOP and re-read this prompt.
2. **No inline Mongoose model declarations.** All models live in `server/src/models/*.js`.
3. **Verify before reporting.** Every claim ("file replaced", "routes mounted", "tests pass") must be backed by raw terminal output pasted in your reply. Do not summarize CC's own success messages — paste the actual `grep` / `node --check` / `curl` output.
4. **Do NOT push to `main` from this session.** Push to the feature branch. Ke will fast-forward main herself.

---

## Files Ke has placed on the feature branch (via GitHub web editor)

These files are already on `day3-rewards-redemption` when this session begins:

### New files
- `server/src/models/Redemption.js` — new Mongoose model
- `server/src/routes/adminRewards.js` — new admin routes file
- `client/public/redeem.html` — user-facing redemption page
- `client/public/admin-rewards.html` — admin queue page

### Replaced files
- `server/src/services/rewardsService.js` — full replacement (v2.2; tier name update)
- `client/public/achievements.html` — Ke has injected the new MMP widget (Day 3 v2) replacing any prior widget block

### Patches still needed (these are what CC must apply)
- `server/src/routes/rewards.js` — add redemption endpoints (per `rewards_js_patch.md`)
- `server/src/services/emailService.js` — add 3 redemption email functions (per `emailService_js_patch.md`)
- `server/src/index.js` — mount `adminRewards` routes (per `index_js_patch.md`)
- `server/src/models/User.js` — schema enum patch (per `User_schema_patch_v3.md`)

---

## CC Task List (do these in order)

### Task 1 — Verify branch state

```bash
git status
git log --oneline -5
ls -la server/src/models/Redemption.js
ls -la server/src/routes/adminRewards.js
ls -la client/public/redeem.html
ls -la client/public/admin-rewards.html
node --check server/src/services/rewardsService.js
node --check server/src/models/Redemption.js
node --check server/src/routes/adminRewards.js
```

Expect: all files exist, all `node --check` calls silent. Paste output. **STOP** if any file is missing or fails check — the branch isn't ready, ask Ke.

### Task 2 — Apply User.js schema patch

Read `server/src/models/User.js`. Find the `careCredits.transactions[].type` enum. If it exists and is missing any of `['course_evaluation', 'redemption_stripe_credit', 'redemption_giftcard']`, expand the enum to the full 14-value list from `User_schema_patch_v3.md`. If there's no enum constraint, leave it alone. Paste a diff of what you changed (or "no change needed").

```bash
node --check server/src/models/User.js
# Then verify enum contents:
node -e "
import('./server/src/models/User.js').then(m => {
  const path = m.default.schema.path('careCredits.transactions');
  const types = path.schema.path('type');
  console.log('Enum values:', types.enumValues || '(no enum)');
});
"
```

Paste output.

### Task 3 — Apply rewards.js patch

Apply the additions from `rewards_js_patch.md`:
1. Add 3 imports at top: `Redemption`, `Stripe`, and `emailService` (default import + destructure)
2. Add `REDEMPTION_OPTIONS` and `VALID_VENDORS` constants
3. Add `POST /redeem` route
4. Add `GET /my-redemptions` route

Verify:

```bash
node --check server/src/routes/rewards.js
grep -n "import.*Redemption\|import.*Stripe\|emailService" server/src/routes/rewards.js
grep -c "router\.\(post\|get\)" server/src/routes/rewards.js
# Expect: 6 routes total (4 existing + redeem + my-redemptions)
grep -n "REDEMPTION_OPTIONS\|VALID_VENDORS" server/src/routes/rewards.js
# Expect: at least 4 matches
```

Paste output.

### Task 4 — Apply emailService.js patch

Append to `server/src/services/emailService.js` (CommonJS, do NOT convert to ESM):
1. Add `formatVendorName` helper
2. Add `sendRedemptionConfirmation`
3. Add `sendRedemptionAdminAlert`
4. Add `sendGiftCardCode`
5. Add all three function names to existing `module.exports = { ... }` block

Verify:

```bash
node --check server/src/services/emailService.js
grep -c "formatVendorName\|sendRedemptionConfirmation\|sendRedemptionAdminAlert\|sendGiftCardCode" \
  server/src/services/emailService.js
# Expect: 8+ matches (4 fns × ~2 references each)

# Verify exports work:
node -e "
const svc = require('./server/src/services/emailService');
console.log('sendRedemptionConfirmation:', typeof svc.sendRedemptionConfirmation);
console.log('sendRedemptionAdminAlert:', typeof svc.sendRedemptionAdminAlert);
console.log('sendGiftCardCode:', typeof svc.sendGiftCardCode);
"
# Expect: 'function' three times
```

Paste output.

### Task 5 — Apply index.js patch

Per `index_js_patch.md`:
1. Add `import adminRewardsRoutes from './routes/adminRewards.js';`
2. Add `app.use('/api/admin/rewards', adminRewardsRoutes);` AFTER `app.use('/api/admin', ...)`
3. Add to REQUIRED_ROUTES manifest if present

Verify:

```bash
node --check server/src/index.js
grep -n "adminRewards" server/src/index.js
# Expect: 2-3 lines

# Order check — make sure admin/rewards mount comes AFTER /api/admin:
grep -n "app\.use.*api/admin" server/src/index.js
```

Paste output.

### Task 6 — Commit and push

```bash
git add -A
git status
git diff --cached --stat
```

Paste the diff stat. Confirm it shows expected files (no surprises in `interactiveCourseRoutes.js`, no node_modules, no .env).

Then:

```bash
git commit -m "Day 3: Mastery Mark Points redemption (Stripe credit + gift cards + admin queue)

- New Redemption model
- POST /api/rewards/redeem (Stripe credit auto-fulfilled, gift card pending)
- GET /api/rewards/my-redemptions (user history)
- /api/admin/rewards/{queue,stats,fulfill,cancel}
- 3 email templates (user confirmation, admin alert, gift card code)
- redeem.html (user) + admin-rewards.html (admin)
- Tier rename: Capable/Proficient/Skilled/Seasoned
- Widget v2 (MMP terminology, redeem CTA)
- Schema enum expanded for redemption types"

git push -u origin day3-rewards-redemption
```

Paste push output. Stop here. Do NOT merge to main.

### Task 7 — Final verification report

Reply with:
- All file paths touched
- Final line counts (`wc -l` of each modified file)
- The 6 verification grep outputs from above
- Any warnings or errors encountered

Format:

```
=== Day 3 Deployment Report ===

Files modified:
  server/src/models/User.js          [LINES] [SHA]
  server/src/services/rewardsService.js   [LINES] [SHA]
  server/src/routes/rewards.js       [LINES] [SHA]
  server/src/services/emailService.js [LINES] [SHA]
  server/src/index.js                 [LINES] [SHA]
  server/src/models/Redemption.js    [LINES] (new)
  server/src/routes/adminRewards.js  [LINES] (new)
  client/public/redeem.html          [LINES] (new)
  client/public/admin-rewards.html   [LINES] (new)
  client/public/achievements.html    [LINES] [SHA] (Ke modified)

Verification outputs:
  [paste each grep result]

Branch: day3-rewards-redemption
Pushed: yes
Merged to main: no (Ke will fast-forward)
```

---

## After CC finishes — Ke's checklist

These steps Ke does manually:

1. **Set Render env var:**
   - Go to Render dashboard → API service → Environment
   - Add `ADMIN_ALERT_EMAIL=hello@counselorready.com` (or her preferred admin email)
   - Confirm `STRIPE_SECRET_KEY` is already set (existing — should be, since payments.js uses it)
   
2. **Fast-forward main:**
   ```bash
   git checkout main
   git merge --ff-only day3-rewards-redemption
   git push origin main
   ```
   Render auto-deploys.

3. **Smoke test post-deploy** (~2 min after push):
   ```bash
   TOKEN="<your_token>"
   
   # Balance still works
   curl -s -H "Authorization: Bearer $TOKEN" https://api.counselorready.com/api/rewards/balance
   
   # Empty redemption history
   curl -s -H "Authorization: Bearer $TOKEN" https://api.counselorready.com/api/rewards/my-redemptions
   # Expect: { redemptions: [] }
   
   # Try redeeming with no balance — should 400
   curl -s -X POST -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
     -d '{"type":"stripe_credit_10"}' \
     https://api.counselorready.com/api/rewards/redeem
   # Expect: { error: "Insufficient balance" }
   
   # Admin queue (with admin token)
   curl -s -H "Authorization: Bearer $ADMIN_TOKEN" \
     https://api.counselorready.com/api/admin/rewards/stats
   # Expect: { pending: 0, fulfilled: 0, cancelled: 0, totalFulfilledValue: 0, ... }
   ```

4. **Visit pages:**
   - https://counselorready.com/achievements.html — widget should show new MMP terminology
   - https://counselorready.com/redeem.html — should load (3 locked options if balance < 500)
   - https://counselorready.com/admin-rewards.html — should load with empty queue (admin login required)

---

## If anything fails

- **Frontend pages 404:** static site cache; force refresh, wait 2 min for Render static deploy.
- **Backend 500 on /redeem:** check Render logs for `[REWARDS]` errors. Likely Stripe customer ID missing or env var unset.
- **Email not sending:** check `ADMIN_ALERT_EMAIL` env var, check Resend dashboard for error logs.
- **Schema validation error on redemption write:** the enum patch didn't take. Re-run Task 2.
- **404 on /api/admin/rewards/queue:** index.js mount didn't take or wrong order. Re-run Task 5.

---

**End of Day 3 deployment prompt.**
