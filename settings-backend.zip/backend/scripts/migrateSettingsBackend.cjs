// server/scripts/migrateSettingsBackend.cjs
// =============================================================================
// MIGRATION — Backfill new fields for the expanded Settings backend
// =============================================================================
// Run ONCE via Render shell:
//   node server/scripts/migrateSettingsBackend.cjs
//
// What it does:
//   1. Sets isPrelicensed on existing Credential documents
//   2. Initializes notifications.{marketingEmail, marketingSms, quietHours*} for all users
//   3. Initializes hardshipPause sub-doc for VIP users
//   4. Generates referralCode for users who don't have one yet
//
// Safe to re-run — uses $set with default-only writes via $exists checks.
// =============================================================================

require('dotenv').config();
const mongoose = require('mongoose');

const MONGODB_URI = process.env.MONGODB_URI;
if (!MONGODB_URI) {
  console.error('MONGODB_URI not set');
  process.exit(1);
}

(async () => {
  await mongoose.connect(MONGODB_URI);
  const db = mongoose.connection.db;

  console.log('Starting migration...');

  // -- 1. Credential.isPrelicensed --
  const credCol = db.collection('credentials');

  const preLicResult = await credCol.updateMany(
    { licenseNumber: { $regex: /^prelicensed$/i } },
    { $set: { licenseNumber: 'PRELICENSED', isPrelicensed: true } }
  );
  console.log(`  ✓ Marked ${preLicResult.modifiedCount} credentials as PRELICENSED`);

  const nonPreResult = await credCol.updateMany(
    { isPrelicensed: { $exists: false }, licenseNumber: { $ne: 'PRELICENSED' } },
    { $set: { isPrelicensed: false } }
  );
  console.log(`  ✓ Set isPrelicensed=false on ${nonPreResult.modifiedCount} non-prelicensed credentials`);

  // -- 2. User notification defaults --
  const userCol = db.collection('users');

  const notifDefaults = {
    'notifications.marketingEmail':    false,
    'notifications.marketingSms':      false,
    'notifications.quietHoursEnabled': false,
    'notifications.quietHoursFrom':    '22:00',
    'notifications.quietHoursTo':      '07:00',
  };

  for (const [field, value] of Object.entries(notifDefaults)) {
    const r = await userCol.updateMany(
      { [field]: { $exists: false } },
      { $set: { [field]: value } }
    );
    console.log(`  ✓ Set ${field} default on ${r.modifiedCount} users`);
  }

  // -- 3. Hardship pause for VIPs --
  const hardshipResult = await userCol.updateMany(
    { 'subscription.plan': { $in: ['vip', 'annual_vip'] }, hardshipPause: { $exists: false } },
    { $set: {
      'hardshipPause.monthsAvailable': 1,
      'hardshipPause.monthsAccrued':   1,
      'hardshipPause.lastUsed':        null,
      'hardshipPause.nextEligible':    null,
      'hardshipPause.currentlyPaused': false,
      'hardshipPause.pauseEndsAt':     null,
      'hardshipPause.history':         [],
    }}
  );
  console.log(`  ✓ Initialized hardshipPause on ${hardshipResult.modifiedCount} VIP users`);

  // -- 4. New profile field defaults --
  const profileDefaults = {
    'profile.pronouns':        '',
    'profile.npi':             '',
    'profile.specializations': [],
    'recoveryEmail':           '',
    'recoveryEmailVerified':   false,
    'twoFactorEnabled':        false,
    'twoFactorBackupCodes':    [],
  };

  for (const [field, value] of Object.entries(profileDefaults)) {
    const r = await userCol.updateMany(
      { [field]: { $exists: false } },
      { $set: { [field]: value } }
    );
    console.log(`  ✓ Set ${field} default on ${r.modifiedCount} users`);
  }

  // -- 5. Generate referral codes for users without one --
  const usersNeedingCode = await userCol.find(
    { $or: [{ referralCode: { $exists: false } }, { referralCode: '' }, { referralCode: null }] },
    { projection: { _id: 1, email: 1, 'profile.firstName': 1 } }
  ).toArray();

  let codesGenerated = 0;
  for (const u of usersNeedingCode) {
    const firstPart = ((u.profile?.firstName || u.email.split('@')[0]) || 'XXX')
      .replace(/[^A-Za-z]/g, '').slice(0, 3).toUpperCase().padEnd(3, 'X');
    const lastPart = u._id.toString().slice(-4).toUpperCase();
    const code = `${firstPart}${lastPart}`;
    await userCol.updateOne({ _id: u._id }, { $set: { referralCode: code } });
    codesGenerated++;
  }
  console.log(`  ✓ Generated referral codes for ${codesGenerated} users`);

  console.log('\nMigration complete.');
  await mongoose.disconnect();
  process.exit(0);
})().catch(err => {
  console.error('Migration failed:', err);
  process.exit(1);
});
