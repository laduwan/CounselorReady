// server/src/services/twoFactorService.js
// =============================================================================
// TWO-FACTOR AUTH SERVICE
// =============================================================================
// TOTP (RFC 6238) using speakeasy. QR codes via qrcode npm package.
// Compatible with Google Authenticator, Authy, 1Password, Microsoft Authenticator.
//
// Required: npm install speakeasy qrcode
// =============================================================================

import speakeasy from 'speakeasy';
import qrcode from 'qrcode';
import crypto from 'crypto';

const ISSUER = 'CounselorReady';

/**
 * Generate a new TOTP secret and a QR code data URL for setup.
 * Caller stores the secret on the user (hash/encrypt at rest in production).
 *
 * @param {string} userEmail - The user's email, used as the account label
 * @returns {Promise<{secret: string, qrCodeDataUrl: string, otpAuthUrl: string}>}
 */
export async function generate2FASetup(userEmail) {
  const secretObj = speakeasy.generateSecret({
    length: 20,
    name: `${ISSUER}:${userEmail}`,
    issuer: ISSUER,
  });

  const qrCodeDataUrl = await qrcode.toDataURL(secretObj.otpauth_url);

  return {
    secret:        secretObj.base32,
    otpAuthUrl:    secretObj.otpauth_url,
    qrCodeDataUrl,
  };
}

/**
 * Verify a 6-digit TOTP code against a user's secret.
 * Allows ±1 time-step (30s) of clock drift.
 *
 * @param {string} secret - The user's TOTP secret (base32)
 * @param {string} code   - The 6-digit code submitted by the user
 * @returns {boolean}
 */
export function verify2FACode(secret, code) {
  if (!secret || !/^\d{6}$/.test(String(code))) return false;
  return speakeasy.totp.verify({
    secret,
    encoding: 'base32',
    token: String(code),
    window: 1, // allow ±30s drift
  });
}

/**
 * Generate 10 single-use backup codes for account recovery.
 * Caller stores them hashed (bcrypt) and marks each as used after consumption.
 *
 * @returns {string[]} - 10 codes in format "XXXX-XXXX"
 */
export function generateBackupCodes() {
  const codes = [];
  for (let i = 0; i < 10; i++) {
    const buf = crypto.randomBytes(4).toString('hex').toUpperCase();
    codes.push(`${buf.slice(0, 4)}-${buf.slice(4, 8)}`);
  }
  return codes;
}

/**
 * Verify a backup code against an array of stored codes.
 * Returns the index of the matching code (caller invalidates it after use), or -1.
 *
 * @param {string[]} storedCodes
 * @param {string} submitted
 * @returns {number} index of match, or -1
 */
export function verifyBackupCode(storedCodes, submitted) {
  if (!Array.isArray(storedCodes) || !submitted) return -1;
  const normalized = String(submitted).trim().toUpperCase();
  return storedCodes.findIndex(c => c === normalized);
}
