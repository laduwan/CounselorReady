// server/src/services/dataExportService.js
// =============================================================================
// DATA EXPORT SERVICE
// =============================================================================
// Generates a complete JSON dump of a user's data and emails it via Resend.
// Triggered by POST /api/users/data-export.
// =============================================================================

import { Resend } from 'resend';
import Credential from '../models/Credential.js';
import Certificate from '../models/Certificate.js';
import CELog from '../models/CELog.js';
import InteractiveCourseProgress from '../models/InteractiveCourseProgress.js';

const resend = new Resend(process.env.RESEND_API_KEY);

/**
 * Compile a user's complete data into a JSON object.
 * Add or remove model lookups based on what data your app stores.
 */
async function compileUserData(user) {
  const userId = user._id;

  const [credentials, certificates, ceLogs, courseProgress] = await Promise.all([
    Credential.find({ userId }).lean(),
    Certificate.find({ userId }).lean(),
    CELog.find({ userId }).lean().catch(() => []),
    InteractiveCourseProgress.find({ userId }).lean().catch(() => []),
  ]);

  return {
    exportedAt: new Date().toISOString(),
    user: {
      id:    user._id.toString(),
      email: user.email,
      profile: user.profile,
      subscription: user.subscription,
      notifications: user.notifications,
      createdAt:     user.createdAt,
    },
    credentials,
    certificates,
    ceLogs,
    courseProgress,
    metadata: {
      counts: {
        credentials:    credentials.length,
        certificates:   certificates.length,
        ceLogs:         ceLogs.length,
        courseProgress: courseProgress.length,
      },
      privacyNote:
        'This export contains all data CounselorReady stores about you. ' +
        'It does not include data shared with third parties (Stripe payment records, ' +
        'NBCC ACEP attendance reports). Contact support@counselorready.com for those.',
    },
  };
}

/**
 * Generate the export and email it as a JSON attachment.
 * Call non-blocking: this can take a few seconds for users with lots of data.
 *
 * @param {Object} user - Mongoose User document
 */
export async function generateUserDataExport(user) {
  try {
    const data = await compileUserData(user);
    const json = JSON.stringify(data, null, 2);
    const filename = `counselorready-data-export-${user._id}-${Date.now()}.json`;

    await resend.emails.send({
      from:    'CounselorReady <noreply@counselorready.com>',
      to:      user.email,
      subject: 'Your CounselorReady data export',
      html: `
        <p>Hi ${user.profile?.firstName || 'there'},</p>
        <p>Attached is the data export you requested. The JSON file contains your profile, credentials, certificates, CE log, and course completion records.</p>
        <p>If you didn't request this, please change your password immediately and contact support.</p>
        <p>— The CounselorReady Team</p>
      `,
      attachments: [{
        filename,
        content: Buffer.from(json, 'utf-8'),
      }],
    });

    console.log(`[dataExport] sent export for user ${user._id} (${json.length} bytes)`);
    return { success: true, bytes: json.length };
  } catch (err) {
    console.error('[dataExport] failed:', err);
    // Optionally email user that export failed
    try {
      await resend.emails.send({
        from:    'CounselorReady <noreply@counselorready.com>',
        to:      user.email,
        subject: 'CounselorReady data export — issue',
        html:    '<p>We hit a problem generating your data export. Please try again from Settings, or reply to this message and we will investigate.</p>',
      });
    } catch { /* swallow */ }
    return { success: false, error: err.message };
  }
}
