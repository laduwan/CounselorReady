// server/src/routes/users-additions.js
// =============================================================================
// USER ROUTE ADDITIONS — Add these endpoints to the existing users.js router
// =============================================================================
// New endpoints:
//   POST /api/users/notifications/test   — send test email or SMS
//   POST /api/users/data-export          — request JSON export of all user data
//   PUT  /api/users/recovery-email       — set/update recovery email + send verification
//   GET  /api/users/recovery-email/verify/:token — verify recovery email
//
// Also: profile PUT must accept new fields (pronouns, npi, specializations, supervisor)
//       and notifications PUT must accept marketingEmail/Sms + quiet hours.
// =============================================================================

import express from 'express';
import crypto from 'crypto';
import User from '../models/User.js';
import { requireAuth } from '../middleware/auth.js';
import { sendEmail } from '../services/emailService.js';      // existing Resend wrapper
import { sendSms } from '../services/smsService.js';           // existing Twilio wrapper
import { generateUserDataExport } from '../services/dataExportService.js';

const router = express.Router(); // merge into existing router

// =============================================================================
// PROFILE PUT — Accept new fields (merge into existing /profile handler)
// =============================================================================
//
// In your existing PUT /api/users/profile handler, accept these additional fields
// from req.body and persist them on user.profile or user (top-level for some):
//
//   const allowed = [
//     // existing
//     'firstName', 'lastName', 'phone', 'state', 'timezone', 'certificateName',
//     // NEW
//     'pronouns', 'npi', 'specializations', 'supervisor',
//   ];
//
//   const update = {};
//   for (const key of allowed) {
//     if (req.body[key] !== undefined) update[`profile.${key}`] = req.body[key];
//   }
//
//   // NPI validation
//   if (update['profile.npi'] && !/^\d{10}$/.test(update['profile.npi'])) {
//     return res.status(400).json({ error: 'NPI must be exactly 10 digits' });
//   }
//
//   const user = await User.findByIdAndUpdate(
//     req.user._id, { $set: update }, { new: true, runValidators: true }
//   );
//   res.json(user);
//
// =============================================================================

// =============================================================================
// NOTIFICATIONS PUT — Accept new fields (merge into existing /notifications handler)
// =============================================================================
//
// In your existing PUT /api/users/notifications handler, expand the allow-list:
//
//   const allowed = [
//     // existing
//     'emailReminders', 'smsReminders', 'weeklyProgress',
//     'fallingBehindAlert', 'ceMilestones', 'courseProgressReminders',
//     // NEW
//     'marketingEmail', 'marketingSms',
//     'quietHoursEnabled', 'quietHoursFrom', 'quietHoursTo',
//   ];
//
//   const update = {};
//   for (const key of allowed) {
//     if (req.body[key] !== undefined) update[`notifications.${key}`] = req.body[key];
//   }
//
//   // Time format validation
//   const timeRe = /^([01]\d|2[0-3]):[0-5]\d$/;
//   if (update['notifications.quietHoursFrom'] && !timeRe.test(update['notifications.quietHoursFrom'])) {
//     return res.status(400).json({ error: 'quietHoursFrom must be HH:mm' });
//   }
//   if (update['notifications.quietHoursTo'] && !timeRe.test(update['notifications.quietHoursTo'])) {
//     return res.status(400).json({ error: 'quietHoursTo must be HH:mm' });
//   }
//
//   await User.findByIdAndUpdate(req.user._id, { $set: update });
//   res.json({ ok: true });
//
// =============================================================================

// =============================================================================
// POST /api/users/notifications/test — Send test email or SMS
// =============================================================================
router.post('/notifications/test', requireAuth, async (req, res) => {
  try {
    const { channel } = req.body;
    if (!['email', 'sms'].includes(channel)) {
      return res.status(400).json({ error: 'channel must be "email" or "sms"' });
    }

    const user = await User.findById(req.user._id);
    if (!user) return res.status(404).json({ error: 'User not found' });

    if (channel === 'email') {
      if (!user.email) return res.status(400).json({ error: 'No email on file' });
      await sendEmail({
        to: user.email,
        subject: 'CounselorReady — Test Notification',
        html: `<p>Hi ${user.profile?.firstName || 'there'},</p>
               <p>This is a test notification from CounselorReady. If you received this, your email notifications are working.</p>
               <p>— The CounselorReady Team</p>`,
      });
    } else {
      if (!user.profile?.phone) return res.status(400).json({ error: 'No phone on file' });
      await sendSms({
        to: user.profile.phone,
        body: 'CounselorReady test message. SMS notifications are working. Reply STOP to opt out.',
      });
    }

    return res.json({ sent: true, channel });
  } catch (err) {
    console.error('[notifications/test] error:', err);
    return res.status(500).json({ error: 'Failed to send test notification' });
  }
});

// =============================================================================
// POST /api/users/data-export — Generate JSON export, email to user
// =============================================================================
router.post('/data-export', requireAuth, async (req, res) => {
  try {
    const user = await User.findById(req.user._id);
    if (!user) return res.status(404).json({ error: 'User not found' });

    // Rate limit: 1 export per 24h
    if (user.lastDataExportAt && (Date.now() - user.lastDataExportAt.getTime() < 24 * 60 * 60 * 1000)) {
      return res.status(429).json({ error: 'Data export already requested in the last 24 hours.' });
    }

    // Kick off async — return immediately, deliver via email
    user.lastDataExportAt = new Date();
    await user.save();

    generateUserDataExport(user).catch(err => {
      console.error('[data-export] generation failed:', err);
    });

    return res.json({ requested: true, message: 'Export will be emailed shortly.' });
  } catch (err) {
    console.error('[data-export] error:', err);
    return res.status(500).json({ error: 'Failed to request data export' });
  }
});

// =============================================================================
// PUT /api/users/recovery-email — Set or clear recovery email
// =============================================================================
router.put('/recovery-email', requireAuth, async (req, res) => {
  try {
    const { recoveryEmail } = req.body;

    // Allow clearing
    if (!recoveryEmail) {
      await User.findByIdAndUpdate(req.user._id, {
        recoveryEmail: '',
        recoveryEmailVerified: false,
        recoveryEmailToken: null,
        recoveryEmailExpires: null,
      });
      return res.json({ cleared: true });
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(recoveryEmail)) {
      return res.status(400).json({ error: 'Invalid email address' });
    }

    const user = await User.findById(req.user._id);
    if (recoveryEmail.toLowerCase() === user.email.toLowerCase()) {
      return res.status(400).json({ error: 'Recovery email must differ from primary email' });
    }

    const token = crypto.randomBytes(32).toString('hex');
    user.recoveryEmail         = recoveryEmail.toLowerCase();
    user.recoveryEmailVerified = false;
    user.recoveryEmailToken    = token;
    user.recoveryEmailExpires  = new Date(Date.now() + 24 * 60 * 60 * 1000); // 24h
    await user.save();

    const baseUrl = process.env.PUBLIC_APP_URL || 'https://counselorready.com';
    const verifyUrl = `${baseUrl}/api/users/recovery-email/verify/${token}`;

    await sendEmail({
      to: recoveryEmail,
      subject: 'Verify your CounselorReady recovery email',
      html: `<p>Confirm this address as your CounselorReady recovery email by clicking below:</p>
             <p><a href="${verifyUrl}">Verify recovery email</a></p>
             <p>If you did not request this, ignore this message. The link expires in 24 hours.</p>`,
    });

    return res.json({ pendingVerification: true });
  } catch (err) {
    console.error('[recovery-email] error:', err);
    return res.status(500).json({ error: 'Failed to update recovery email' });
  }
});

// =============================================================================
// GET /api/users/recovery-email/verify/:token — Verification link target
// =============================================================================
router.get('/recovery-email/verify/:token', async (req, res) => {
  try {
    const user = await User.findOne({
      recoveryEmailToken: req.params.token,
      recoveryEmailExpires: { $gt: new Date() },
    }).select('+recoveryEmailToken +recoveryEmailExpires');

    if (!user) {
      return res.status(400).send('<h1>Link expired or invalid</h1><p>Request a new verification from Settings.</p>');
    }

    user.recoveryEmailVerified = true;
    user.recoveryEmailToken    = null;
    user.recoveryEmailExpires  = null;
    await user.save();

    return res.send('<h1>Recovery email verified</h1><p>You can close this window.</p>');
  } catch (err) {
    console.error('[recovery-email verify] error:', err);
    return res.status(500).send('Server error');
  }
});

export default router;
