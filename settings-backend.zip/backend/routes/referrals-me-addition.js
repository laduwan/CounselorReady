// server/src/routes/referrals-me-addition.js
// =============================================================================
// REFERRALS /me ENDPOINT — Add to existing referrals.js (516L) router
// =============================================================================
// Powers the "Refer a Colleague" card in Settings → Account.
//
// Add to your existing referrals.js. Adjust field names and Referral model
// references to match your existing schema.
// =============================================================================

import express from 'express';
import User from '../models/User.js';
import Referral from '../models/Referral.js'; // adjust if your model is named differently
import { requireAuth } from '../middleware/auth.js';

const router = express.Router();

// =============================================================================
// GET /api/referrals/me — Personal stats and code
// =============================================================================
router.get('/me', requireAuth, async (req, res) => {
  try {
    const user = await User.findById(req.user._id);
    if (!user) return res.status(404).json({ error: 'User not found' });

    // Most referral systems store the user's code on the User doc
    // or generate it on the fly from email/_id
    const code = user.referralCode || generateCodeFromUser(user);

    // Persist generated code if it didn't exist yet
    if (!user.referralCode) {
      user.referralCode = code;
      await user.save();
    }

    // Look up referrals where this user is the referrer
    // Adjust field name (referrerId vs referredBy vs sourceUserId) to match your schema
    const referrals = await Referral.find({ referrerId: user._id });

    const referralsCount = referrals.length;

    // Sum up reward amounts (in cents) — adjust based on your model
    const rewards = referrals.reduce((sum, r) => sum + (r.rewardAmountCents || 0), 0);

    // Optional: count how many referrals are "pending" vs "completed"
    const completed = referrals.filter(r => r.status === 'completed').length;
    const pending   = referrals.filter(r => r.status === 'pending').length;

    return res.json({
      code,
      referralsCount,
      completed,
      pending,
      rewards,         // total cents
      shareUrl: `https://counselorready.com/?ref=${encodeURIComponent(code)}`,
    });
  } catch (err) {
    console.error('[referrals/me] error:', err);
    return res.status(500).json({ error: 'Failed to load referral info' });
  }
});

// =============================================================================
// Helper — derive a referral code if not already on the user
// =============================================================================
function generateCodeFromUser(user) {
  // Format: first 3 letters of first name + last 4 of _id
  const firstPart = (user.profile?.firstName || user.email.split('@')[0])
    .replace(/[^A-Za-z]/g, '')
    .slice(0, 3)
    .toUpperCase()
    .padEnd(3, 'X');
  const lastPart = user._id.toString().slice(-4).toUpperCase();
  return `${firstPart}${lastPart}`;
}

export default router;
