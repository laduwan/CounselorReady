// server/src/routes/subscription-additions.js
// =============================================================================
// SUBSCRIPTION ROUTE ADDITIONS — VIP Hardship Pause + Billing History
// =============================================================================
//   GET  /api/subscription/hardship-pause   — current state
//   POST /api/subscription/hardship-pause   — initiate 1-month pause
//   GET  /api/subscription/invoices         — last 12 months from Stripe
//
// Add these to your existing subscription.js router (or merge as a new file
// and register in index.js: app.use('/api/subscription', subscriptionRoutes); ).
// =============================================================================

import express from 'express';
import Stripe from 'stripe';
import User from '../models/User.js';
import { requireAuth } from '../middleware/auth.js';

const router = express.Router();
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);

const VIP_PLANS = ['vip', 'annual_vip'];
const PAUSE_LENGTH_DAYS = 30;
const ACCRUAL_INTERVAL_DAYS = 365; // 1 month earned per year

// =============================================================================
// Helper — refresh accrued months (called on every read)
// =============================================================================
function refreshAccrual(user) {
  // Each year of VIP membership accrues 1 month, capped at, say, 3 unused
  const MAX_BANK = 3;
  const now = Date.now();

  // If they've been VIP since X, they accrue (now - X) / 365d months
  // Use subscription.startedAt or an explicit field; fall back to user.createdAt
  const startedAt = user.subscription?.startedAt || user.createdAt;
  if (!startedAt) return user.hardshipPause?.monthsAvailable || 0;

  const yearsAsVip = Math.floor((now - new Date(startedAt).getTime()) / (ACCRUAL_INTERVAL_DAYS * 24 * 60 * 60 * 1000));
  const totalEarned = Math.min(yearsAsVip + 1, MAX_BANK + (user.hardshipPause?.monthsAccrued || 0));

  if (!user.hardshipPause) user.hardshipPause = {};
  user.hardshipPause.monthsAccrued  = Math.max(user.hardshipPause.monthsAccrued || 0, totalEarned);

  // monthsAvailable = accrued - used (used = accrued - currentlyAvailable; recalc from history)
  const usedCount = (user.hardshipPause.history || []).length;
  user.hardshipPause.monthsAvailable = Math.max(0, user.hardshipPause.monthsAccrued - usedCount);

  return user.hardshipPause.monthsAvailable;
}

// =============================================================================
// GET /api/subscription/hardship-pause
// =============================================================================
router.get('/hardship-pause', requireAuth, async (req, res) => {
  try {
    const user = await User.findById(req.user._id);
    if (!user) return res.status(404).json({ error: 'User not found' });

    const plan = user.subscription?.plan;
    if (!VIP_PLANS.includes(plan)) {
      return res.status(403).json({ error: 'Hardship pause is a VIP benefit' });
    }

    refreshAccrual(user);
    await user.save();

    const hp = user.hardshipPause || {};
    return res.json({
      monthsAvailable: hp.monthsAvailable ?? 0,
      monthsAccrued:   hp.monthsAccrued ?? 0,
      lastUsed:        hp.lastUsed,
      nextEligible:    hp.nextEligible,
      currentlyPaused: !!hp.currentlyPaused,
      pauseEndsAt:     hp.pauseEndsAt,
    });
  } catch (err) {
    console.error('[hardship-pause GET] error:', err);
    return res.status(500).json({ error: 'Failed to load pause status' });
  }
});

// =============================================================================
// POST /api/subscription/hardship-pause — Initiate a 1-month pause
// =============================================================================
router.post('/hardship-pause', requireAuth, async (req, res) => {
  try {
    const user = await User.findById(req.user._id);
    if (!user) return res.status(404).json({ error: 'User not found' });

    const plan = user.subscription?.plan;
    if (!VIP_PLANS.includes(plan)) {
      return res.status(403).json({ error: 'Hardship pause is a VIP benefit' });
    }

    refreshAccrual(user);

    const hp = user.hardshipPause || {};
    if ((hp.monthsAvailable ?? 0) <= 0) {
      return res.status(400).json({ error: 'No pause months available' });
    }
    if (hp.currentlyPaused) {
      return res.status(400).json({ error: 'Subscription is already paused' });
    }

    // Pause via Stripe — keep subscription active but defer billing
    const stripeSubId = user.subscription?.stripeSubscriptionId;
    if (stripeSubId) {
      await stripe.subscriptions.update(stripeSubId, {
        pause_collection: { behavior: 'keep_as_draft' },
      });
    }

    const now = new Date();
    const endsAt = new Date(now.getTime() + PAUSE_LENGTH_DAYS * 24 * 60 * 60 * 1000);

    user.hardshipPause = {
      ...hp,
      monthsAvailable: (hp.monthsAvailable ?? 0) - 1,
      lastUsed:        now,
      nextEligible:    new Date(now.getTime() + ACCRUAL_INTERVAL_DAYS * 24 * 60 * 60 * 1000),
      currentlyPaused: true,
      pauseEndsAt:     endsAt,
      history: [...(hp.history || []), { pausedAt: now, resumedAt: null, reason: req.body.reason || '' }],
    };
    await user.save();

    return res.json({
      paused:           true,
      pauseEndsAt:      endsAt,
      monthsAvailable:  user.hardshipPause.monthsAvailable,
    });
  } catch (err) {
    console.error('[hardship-pause POST] error:', err);
    return res.status(500).json({ error: 'Failed to pause subscription' });
  }
});

// =============================================================================
// POST /api/subscription/hardship-pause/resume — Manual resume (admin or scheduled)
// =============================================================================
router.post('/hardship-pause/resume', requireAuth, async (req, res) => {
  try {
    const user = await User.findById(req.user._id);
    if (!user || !user.hardshipPause?.currentlyPaused) {
      return res.status(400).json({ error: 'No active pause' });
    }

    const stripeSubId = user.subscription?.stripeSubscriptionId;
    if (stripeSubId) {
      await stripe.subscriptions.update(stripeSubId, {
        pause_collection: '', // resumes billing
      });
    }

    user.hardshipPause.currentlyPaused = false;
    user.hardshipPause.pauseEndsAt     = null;
    const lastEntry = user.hardshipPause.history?.[user.hardshipPause.history.length - 1];
    if (lastEntry && !lastEntry.resumedAt) lastEntry.resumedAt = new Date();
    await user.save();

    return res.json({ resumed: true });
  } catch (err) {
    console.error('[hardship-pause resume] error:', err);
    return res.status(500).json({ error: 'Failed to resume subscription' });
  }
});

// =============================================================================
// GET /api/subscription/invoices — last 12 from Stripe
// =============================================================================
router.get('/invoices', requireAuth, async (req, res) => {
  try {
    const user = await User.findById(req.user._id);
    const customerId = user?.subscription?.stripeCustomerId;
    if (!customerId) return res.json({ invoices: [] });

    const list = await stripe.invoices.list({ customer: customerId, limit: 12 });

    const invoices = list.data.map(inv => ({
      id:          inv.id,
      date:        new Date(inv.created * 1000),
      description: inv.lines?.data?.[0]?.description || 'CounselorReady subscription',
      amount:      inv.amount_paid || inv.amount_due, // cents
      currency:    inv.currency,
      status:      inv.status,
      url:         inv.hosted_invoice_url || inv.invoice_pdf,
      pdf:         inv.invoice_pdf,
    }));

    return res.json({ invoices });
  } catch (err) {
    console.error('[invoices] error:', err);
    return res.status(500).json({ error: 'Failed to load invoices' });
  }
});

export default router;
