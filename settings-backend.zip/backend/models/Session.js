// server/src/models/Session.js
// =============================================================================
// SESSION MODEL — Tracks active login sessions for the Security tab in Settings.
// One document per active JWT/login. Auto-expires after 90 days of inactivity.
// =============================================================================

import mongoose from 'mongoose';

const sessionSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
    index: true,
  },

  // SHA-256 hash of the JWT — never store the raw token
  tokenHash: {
    type: String,
    required: true,
    index: true,
  },

  // Parsed from User-Agent header
  browser:  { type: String, default: 'Unknown' },
  os:       { type: String, default: 'Unknown' },
  device:   { type: String, default: 'Unknown' },

  // Last-known IP and rough geolocation
  ip:       { type: String, default: '' },
  location: { type: String, default: '' }, // "Atlanta, GA, US" or similar

  // Activity tracking
  createdAt:  { type: Date, default: Date.now, index: true },
  lastActive: { type: Date, default: Date.now, index: true },

  // Status
  revoked:   { type: Boolean, default: false },
  revokedAt: { type: Date,    default: null },
}, { timestamps: false });

// Auto-delete after 90 days of inactivity
sessionSchema.index({ lastActive: 1 }, { expireAfterSeconds: 60 * 60 * 24 * 90 });

// Find all active (non-revoked) sessions for a user
sessionSchema.statics.findActiveByUser = function(userId) {
  return this.find({ userId, revoked: false }).sort({ lastActive: -1 });
};

// Revoke a specific session
sessionSchema.statics.revoke = function(sessionId, userId) {
  return this.findOneAndUpdate(
    { _id: sessionId, userId },
    { revoked: true, revokedAt: new Date() },
    { new: true }
  );
};

// Revoke all sessions for a user except the current one
sessionSchema.statics.revokeAllExcept = function(userId, currentTokenHash) {
  return this.updateMany(
    { userId, tokenHash: { $ne: currentTokenHash }, revoked: false },
    { revoked: true, revokedAt: new Date() }
  );
};

export default mongoose.model('Session', sessionSchema);
