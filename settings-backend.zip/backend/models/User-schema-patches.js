// =============================================================================
// USER SCHEMA PATCHES — Drop-in additions to server/src/models/User.js
// =============================================================================
// These fields support the expanded Settings page (Profile, Notifications,
// Security tabs). Add them to the existing User schema; do NOT replace the file.
// =============================================================================

// ---- Add to userSchema definition ----

const userSchemaAdditions = {
  // -- Profile expansions --
  profile: {
    // ... existing profile fields (firstName, lastName, phone, state, timezone, certificateName)

    pronouns: { type: String, default: '', trim: true, maxlength: 50 },

    npi: {
      type: String,
      default: '',
      validate: {
        validator: v => !v || /^\d{10}$/.test(v),
        message: 'NPI must be exactly 10 digits',
      },
    },

    specializations: {
      type: [String],
      default: [],
      validate: {
        validator: arr => arr.every(s => typeof s === 'string' && s.length <= 50),
        message: 'Invalid specialization',
      },
    },

    supervisor: {
      name:        { type: String, default: '', trim: true, maxlength: 200 },
      license:     { type: String, default: '', trim: true, maxlength: 50 },
      credentials: { type: String, default: '', trim: true, maxlength: 100 },
      startDate:   { type: Date, default: null },
    },
  },

  // -- Recovery / security --
  recoveryEmail:         { type: String, default: '', trim: true, lowercase: true },
  recoveryEmailVerified: { type: Boolean, default: false },
  recoveryEmailToken:    { type: String, default: null, select: false },
  recoveryEmailExpires:  { type: Date, default: null, select: false },

  // -- 2FA (TOTP) --
  twoFactorEnabled:        { type: Boolean, default: false },
  twoFactorSecret:         { type: String, default: null, select: false },
  twoFactorBackupCodes:    { type: [String], default: [], select: false },
  twoFactorEnabledAt:      { type: Date, default: null },

  // -- Notifications expansions --
  notifications: {
    // existing: emailReminders, smsReminders, weeklyProgress,
    //           fallingBehindAlert, ceMilestones, courseProgressReminders

    // marketing/transactional split
    marketingEmail: { type: Boolean, default: false },
    marketingSms:   { type: Boolean, default: false },

    // quiet hours
    quietHoursEnabled: { type: Boolean, default: false },
    quietHoursFrom:    { type: String, default: '22:00' }, // "HH:mm"
    quietHoursTo:      { type: String, default: '07:00' },
  },

  // -- Hardship pause (VIP feature) --
  hardshipPause: {
    monthsAvailable: { type: Number, default: 1, min: 0 },
    monthsAccrued:   { type: Number, default: 1, min: 0 }, // total earned over time
    lastUsed:        { type: Date, default: null },
    nextEligible:    { type: Date, default: null },
    currentlyPaused: { type: Boolean, default: false },
    pauseEndsAt:     { type: Date, default: null },
    history: [{
      pausedAt:  Date,
      resumedAt: Date,
      reason:    String,
    }],
  },

  // -- Data export tracking --
  lastDataExportAt: { type: Date, default: null },
};

// =============================================================================
// USAGE
// =============================================================================
// In server/src/models/User.js, merge these into your existing schema:
//
//   const userSchema = new mongoose.Schema({
//     email: ...,
//     password: ...,
//     profile: {
//       firstName: ...,
//       lastName: ...,
//       phone: ...,
//       // ... existing fields
//       // PASTE the additions from `userSchemaAdditions.profile` here
//       pronouns: { type: String, default: '', trim: true, maxlength: 50 },
//       npi: { ... },
//       specializations: { ... },
//       supervisor: { ... },
//     },
//     // ... existing top-level fields
//     // PASTE the rest of the top-level additions here
//     recoveryEmail: { ... },
//     twoFactorEnabled: { ... },
//     // etc.
//   });
//
// =============================================================================

export default userSchemaAdditions;
