// =============================================================================
// CREDENTIAL SCHEMA PATCHES — Drop-in additions to server/src/models/Credential.js
// =============================================================================
// Adds isPrelicensed flag with auto-derivation from licenseNumber === 'PRELICENSED'.
// Add field + both hooks to the existing Credential schema.
// =============================================================================

// ---- Field to add ----
//
//   isPrelicensed: { type: Boolean, default: false, index: true }
//
// ---- Pre-save hook (handles new docs and direct .save() calls) ----

const preSaveHook = function(next) {
  if (this.isModified('licenseNumber')) {
    const norm = (this.licenseNumber || '').trim();
    if (norm.toUpperCase() === 'PRELICENSED') {
      this.licenseNumber = 'PRELICENSED'; // canonical uppercase form
      this.isPrelicensed = true;
    } else {
      this.licenseNumber = norm;
      this.isPrelicensed = false;
    }
  }
  next();
};

// ---- Pre-update hook (handles findOneAndUpdate / updateOne / etc.) ----

const preUpdateHook = function(next) {
  const update = this.getUpdate() || {};
  // Handle both top-level and $set forms
  const target = update.$set ? update.$set : update;

  if (target.licenseNumber !== undefined) {
    const norm = (target.licenseNumber || '').trim();
    if (norm.toUpperCase() === 'PRELICENSED') {
      target.licenseNumber  = 'PRELICENSED';
      target.isPrelicensed  = true;
    } else {
      target.licenseNumber  = norm;
      target.isPrelicensed  = false;
    }
    this.setUpdate(update);
  }
  next();
};

// =============================================================================
// USAGE — patch into server/src/models/Credential.js
// =============================================================================
//
// import mongoose from 'mongoose';
//
// const credentialSchema = new mongoose.Schema({
//   userId:         { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
//   credentialType: { type: String, required: true },
//   name:           { type: String, required: true },
//   code:           { type: String },
//   licenseNumber:  { type: String, required: true, trim: true },
//   isPrelicensed:  { type: Boolean, default: false, index: true },     // ← ADD
//   state:          { type: String, required: true },
//   issuingBody:    { type: String },
//   issueDate:      { type: Date },
//   expirationDate: { type: Date },
//   renewalCycle:   { type: String, enum: ['1year','2years','3years','5years'], default: '2years' },
//   totalCEUsRequired: { type: Number },
//   // ... other existing fields
// }, { timestamps: true });
//
// credentialSchema.pre('save',             function(next) { /* paste preSaveHook body */ });
// credentialSchema.pre('findOneAndUpdate', function(next) { /* paste preUpdateHook body */ });
// credentialSchema.pre('updateOne',        function(next) { /* paste preUpdateHook body */ });
//
// export default mongoose.model('Credential', credentialSchema);
//
// =============================================================================

export { preSaveHook, preUpdateHook };
