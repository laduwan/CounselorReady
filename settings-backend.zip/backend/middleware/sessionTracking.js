// server/src/middleware/sessionTracking.js
// =============================================================================
// SESSION TRACKING MIDDLEWARE
// =============================================================================
// Runs after auth middleware. Records the session if new, otherwise updates
// lastActive. Attaches the active session document to req.session for use in
// "this device" detection on the Security tab.
//
// Required: npm install useragent
// =============================================================================

import crypto from 'crypto';
import useragent from 'useragent';
import Session from '../models/Session.js';

/**
 * SHA-256 hash a JWT for session lookup. Never store raw tokens.
 */
export function hashToken(token) {
  return crypto.createHash('sha256').update(String(token)).digest('hex');
}

/**
 * Best-effort city/region from IP. Replace with a real geo lookup
 * (MaxMind, ipinfo.io, etc.) when ready. For now returns an empty string.
 */
async function lookupLocation(ip) {
  // TODO: integrate ipinfo.io or MaxMind GeoLite2
  return '';
}

/**
 * Express middleware. Must run AFTER your auth middleware that populates
 * req.user and req.token (or req.headers.authorization).
 */
export async function trackSession(req, res, next) {
  try {
    if (!req.user || !req.user._id) return next();

    // Extract token from Authorization header
    const authHeader = req.headers.authorization || '';
    const token = authHeader.replace(/^Bearer\s+/i, '').trim();
    if (!token) return next();

    const tokenHash = hashToken(token);
    const ua = useragent.parse(req.headers['user-agent'] || '');
    const ip = (req.headers['x-forwarded-for'] || req.ip || '').split(',')[0].trim();

    // Upsert session — create if new, update lastActive if existing
    const existing = await Session.findOne({ userId: req.user._id, tokenHash });

    if (existing) {
      // Don't await — keep response fast
      Session.updateOne(
        { _id: existing._id },
        { lastActive: new Date(), ip }
      ).catch(err => console.error('[sessionTracking] update failed:', err));
      req.session = existing;
    } else {
      const location = await lookupLocation(ip);
      const newSession = await Session.create({
        userId:     req.user._id,
        tokenHash,
        browser:    ua.family || 'Unknown',
        os:         ua.os.family || 'Unknown',
        device:     ua.device.family || 'Unknown',
        ip,
        location,
        createdAt:  new Date(),
        lastActive: new Date(),
      });
      req.session = newSession;
    }
    next();
  } catch (err) {
    console.error('[sessionTracking] error:', err);
    // Never fail the request because of session tracking
    next();
  }
}

/**
 * Check whether a token has been revoked (call from auth middleware).
 * Returns true if the session is revoked or missing — caller should reject.
 */
export async function isTokenRevoked(token, userId) {
  if (!token || !userId) return true;
  const tokenHash = hashToken(token);
  const session = await Session.findOne({ userId, tokenHash });
  if (!session) return false; // session not yet created (first request) — allow
  return session.revoked === true;
}
