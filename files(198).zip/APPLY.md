# Fix: course-builder served the marketing page ("logged me out")

## Root cause
`client/index.html` is **Vite's React entry** — it's built and emitted as the deployed
`/index.html`, which `client/public/_redirects` maps the course-builder route to
(`/admin/course-builder -> /index.html`). It had been overwritten with the **marketing
homepage** (no `<div id="root">`, no `/src/main.jsx`), so the build shipped a marketing
page as `/index.html`. Hitting `/admin/course-builder` then served the marketing site
(with a "Sign in" button) and React never booted — which looked like being logged out.
`/auth/me` was returning 200 the whole time; the app simply never loaded.

The marketing homepage is a **separate** file: `client/public/index.html`. The two must
not be confused. This exact break has happened 3x (commits `268e190`, `2875c7e`, `53797f2`).

## What this fix does (4 files)
1. **`client/index.html`** — restored to the React shell (`#root` + `/src/main.jsx`), with
   a header comment explaining what it is and why it must never be marketing HTML.
2. **`client/vite.config.js`** — adds a `verify-react-entry` build guard that **fails the
   build** (on any `vite build`) if the entry loses `#root` or `/src/main.jsx`. A broken
   entry can no longer deploy. (Proven: fails on the old broken file, passes on the fix.)
3. **`CLAUDE.md`** — adds a "Two index.html files" architecture section so future work
   won't reintroduce this; also removes the stray GitHub attachment-link lines at the top.
4. **`client/public/_redirects`** — corrects the misleading header that claimed "fully
   static, no React SPA" (course-builder IS React). Rules unchanged.

No locked files touched. Marketing homepage at `/` is unaffected.

## Apply via Claude Code (feature branch + PR)
```
Fix the course-builder serving the marketing page. Work on a feature branch, not main.
Follow CLAUDE.md. Touch ONLY the four files below. Read each before editing; show diffs.

Replace these files with the versions I'm providing (exact contents):
  - client/index.html
  - client/vite.config.js
  - client/public/_redirects
  - CLAUDE.md

Do NOT modify client/public/index.html (that is the separate marketing homepage and is
correct as-is). Do NOT change any _redirects RULES — only its header comment changed.

After editing, VERIFY with real output:
  grep -c 'id="root"' client/index.html               # expect 1
  grep -c '/src/main.jsx' client/index.html            # expect 1
  grep -c 'verifyReactEntry' client/vite.config.js     # expect >=1
  node --check client/vite.config.js
  head -1 CLAUDE.md                                     # expect the title, not an attachment link
Then run the guard end-to-end to prove it works:
  cd client && npx vite build      # must succeed; then temporarily blank index.html and
                                   # confirm `npx vite build` FAILS with the verify-react-entry
                                   # error, then restore. (optional but recommended)
Show me the grep output and diffs. Open a PR — do not merge to main.
```

## Apply via GitHub web editor (no CC)
Upload/replace these four files with the copies in this folder, commit to a branch, open a PR.
The most important single file is `client/index.html` — restoring it fixes the outage
immediately on the next deploy; the other three prevent recurrence and document why.

## After deploy — confirm fixed
Visit `/admin/course-builder`: it should boot the React app (the builder with the
Supplements tab), not the marketing "Sign in" page. The marketing homepage at `/` is
unchanged.
