/**
 * ceDeadlineReminder.js
 * CounselorReady · GAITP LLC · NBCC ACEP #7760
 *
 * Scheduled job — checks all active credentials for upcoming renewals.
 * Sends SMS (Twilio) + email (Resend) at 90, 60, and 30 days out.
 *
 * Run daily via cron or node-cron:
 *   import { runDeadlineReminders } from '../services/ceDeadlineReminder.js';
 *   cron.schedule('0 9 * * *', runDeadlineReminders); // 9am daily
 *
 * Or standalone: node src/scripts/runDeadlineReminders.js
 */

import mongoose from 'mongoose';
import UserCredential from '../models/UserCredential.js';
import User from '../models/User.js';
import { Resend } from 'resend';
import twilio from 'twilio';

const resend = new Resend(process.env.RESEND_API_KEY);
const twilioClient = twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);
const TWILIO_FROM = process.env.TWILIO_PHONE_NUMBER;
const FROM_EMAIL = 'CounselorReady <support@counselorready.com>';

const REMINDER_DAYS = [90, 60, 30];

export async function runDeadlineReminders() {
  console.log('[CEReminder] Starting deadline check...');
  const now = new Date();
  let sent = 0;

  for (const days of REMINDER_DAYS) {
    const targetDate = new Date(now);
    targetDate.setDate(targetDate.getDate() + days);
    const dayStart = new Date(targetDate.setHours(0, 0, 0, 0));
    const dayEnd = new Date(targetDate.setHours(23, 59, 59, 999));

    // Find credentials expiring on this exact day
    const credentials = await UserCredential.find({
      status: { $in: ['active', 'expiring_soon'] },
      renewalDate: { $gte: dayStart, $lte: dayEnd },
      [`reminderSent_${days}d`]: { $ne: true }
    }).lean();

    for (const cred of credentials) {
      try {
        const user = await User.findById(cred.userId)
          .select('email phone profile.firstName smsOptIn')
          .lean();
        if (!user) continue;

        const firstName = user.profile?.firstName || 'there';
        const credName = cred.name || cred.licenseType || 'your license';
        const remaining = cred.totalCEUsRequired - (cred.totalCEUsCompleted || 0);
        const renewalStr = new Date(cred.renewalDate).toLocaleDateString('en-US', {
          month: 'long', day: 'numeric', year: 'numeric'
        });

        // Email
        await resend.emails.send({
          from: FROM_EMAIL,
          to: user.email,
          subject: `${days} days until your ${credName} renewal`,
          html: `
            <div style="font-family:Georgia,'Times New Roman',serif;max-width:560px;margin:0 auto;color:#1C1208">
              <div style="background:#6B1D34;padding:20px 24px;border-radius:8px 8px 0 0;text-align:center">
                <span style="font-size:20px;font-weight:700">
                  <span style="color:#D0768A">Counselor</span><span style="color:#4A7C59">Ready</span>
                </span>
              </div>
              <div style="background:#FAF7F0;padding:28px 24px;border:1px solid #EDE3D0;border-top:none;border-radius:0 0 8px 8px">
                <p style="font-size:16px;margin:0 0 16px">Hey ${firstName},</p>
                <p style="font-size:15px;margin:0 0 16px;line-height:1.6">
                  Your <strong>${credName}</strong> renewal is coming up on <strong>${renewalStr}</strong> — that's ${days} days from now.
                </p>
                ${remaining > 0 ? `
                <div style="background:#FBF2E0;border:1px solid #ECD9B0;border-radius:6px;padding:14px 16px;margin:0 0 16px">
                  <p style="font-size:14px;margin:0;color:#7A5018;font-weight:600">
                    You still need ${remaining} CE hour${remaining !== 1 ? 's' : ''} to meet your requirement.
                  </p>
                </div>` : `
                <div style="background:#EEF5EA;border:1px solid #C8DDBE;border-radius:6px;padding:14px 16px;margin:0 0 16px">
                  <p style="font-size:14px;margin:0;color:#2A4A18;font-weight:600">
                    You've completed all required CE hours. You're all set!
                  </p>
                </div>`}
                ${remaining > 0 ? `
                <div style="text-align:center;margin:20px 0">
                  <a href="https://counselorready.com/courses.html"
                    style="display:inline-block;padding:12px 28px;background:#4A7C59;color:#fff;text-decoration:none;border-radius:6px;font-weight:600;font-size:14px">
                    Browse Courses
                  </a>
                </div>` : ''}
                <hr style="border:none;border-top:1px solid #EDE3D0;margin:20px 0">
                <p style="font-size:11px;color:#9C8472;text-align:center;margin:0">
                  GAITP LLC · NBCC ACEP Provider #7760
                </p>
              </div>
            </div>
          `
        });

        // SMS (if opted in)
        if (user.phone && user.smsOptIn && TWILIO_FROM) {
          const smsBody = remaining > 0
            ? `CounselorReady: Your ${credName} renews ${renewalStr} (${days} days). You need ${remaining} more CE hrs. Browse courses: counselorready.com/courses`
            : `CounselorReady: Your ${credName} renews ${renewalStr} (${days} days). You're all set — all CE hours completed!`;

          await twilioClient.messages.create({
            body: smsBody,
            from: TWILIO_FROM,
            to: user.phone
          });
        }

        // Mark reminder as sent
        await UserCredential.findByIdAndUpdate(cred._id, {
          [`reminderSent_${days}d`]: true
        });

        sent++;
        console.log(`[CEReminder] ${days}d reminder → ${user.email} (${credName})`);
      } catch (err) {
        console.error(`[CEReminder] Failed for cred ${cred._id}:`, err.message);
      }
    }
  }

  console.log(`[CEReminder] Done. ${sent} reminders sent.`);
  return sent;
}
