# Blog Post Publishing Queue — 19 Posts
## CounselorReady · SEO Content Plan Execution

Each post targets a specific search intent. Write in Ke's voice:
formal credentials + "— KekeTheLPC" closing. Publish via admin-blog.html.

---

### TIER 1 — High Search Volume (publish first)

**2. Florida LMHC CE Requirements 2026**
Target: "Florida LMHC CE requirements"
Angle: Hours needed, ethics mandate, board-approved providers, renewal timeline
CTA: Create free account to track Florida CE

**3. Texas LPC CE Requirements 2026**
Target: "Texas LPC continuing education"
Angle: BHEC rules, supervision hours, ethics, jurisprudence exam
CTA: Start tracking Texas CE hours

**4. How Many CE Hours Do I Need? State-by-State Guide**
Target: "how many CE hours do counselors need"
Angle: Comparison table of top 15 states, link to each state page
CTA: Let CounselorReady track it for you

**5. NBCC NCC Certification: CE Requirements Explained**
Target: "NCC certification CE requirements"
Angle: 100 hours/5 years, content area breakdown, ACEP providers
CTA: Browse NBCC-approved courses

**6. What Counts as a CE Hour? (And What Doesn't)**
Target: "what counts as continuing education hours"
Angle: NBCC rules, synchronous vs asynchronous, self-study limits
CTA: All our courses meet NBCC standards

---

### TIER 2 — Medium Volume, High Conversion

**7. Ethics CE for Counselors: Why It's Required and How to Choose**
Target: "ethics CE hours for counselors"
Angle: State mandates, Georgia synchronous requirement, what makes a good ethics course
CTA: Take our ethics course

**8. Free CE for Counselors: What's Actually Available in 2026**
Target: "free CE for counselors"
Angle: CounselorReady free tier (4/month), other free options, quality comparison
CTA: Get 4 free courses/month

**9. How to Track CE Hours Across Multiple Licenses**
Target: "track CE hours multiple states"
Angle: Pain point of dual-licensed clinicians, spreadsheet vs platform, audit readiness
CTA: Import all your licenses

**10. Telehealth CE Requirements by State**
Target: "telehealth CE requirements counselors"
Angle: Which states require it, how many hours, recommended courses
CTA: Take our 6-hour telehealth course

**11. Last-Minute CE: How to Get Hours Before Your Renewal Deadline**
Target: "last minute CE hours counselors"
Angle: Self-paced courses, instant certificates, audit-ready documentation
CTA: Start a course now — certificate in hours

**12. CE Broker: What It Is and How to Report Your Hours**
Target: "CE Broker reporting"
Angle: Which states use it, how to submit, auto-reporting future feature
CTA: Track and export hours from CounselorReady

---

### TIER 3 — Authority Building, Lower Volume

**13. What Is an ACEP Provider? Understanding NBCC Approval**
Target: "NBCC ACEP provider meaning"
Angle: What ACEP means, how to verify, why it matters for your license
CTA: All CounselorReady courses are ACEP #7760

**14. Counselor Burnout: CE That Actually Helps**
Target: "counselor burnout continuing education"
Angle: Self-care as professional development, our burnout course, research
CTA: Take the burnout prevention course

**15. Supervision CE for LPC Supervisors: What You Need to Know**
Target: "LPC supervisor CE requirements"
Angle: CPCS requirements (Georgia), other state supervisor mandates
CTA: Browse supervision courses

**16. Multicultural Competence CE: Beyond the Checkbox**
Target: "multicultural counseling CE"
Angle: Why it matters clinically (not just for renewal), course preview
CTA: Take multicultural competence course

**17. AI in Counseling: Ethical Considerations for 2026**
Target: "AI ethics counseling"
Angle: Emerging issues, our AI ethics course, clinical decision-making
CTA: Take the AI ethics course

**18. How to Prepare for a CE Audit**
Target: "CE audit preparation counselors"
Angle: What boards look for, documentation checklist, audit-ready reports
CTA: Generate audit reports in one click

**19. Career Counseling CE: Staying Current in a Changing Job Market**
Target: "career counseling continuing education"
Angle: Post-pandemic career shifts, our career counseling course
CTA: Take the career counseling course

**20. Addiction Counseling CE: Evidence-Based Approaches for 2026**
Target: "addiction counseling CE hours"
Angle: SBIRT, MAT integration, our addiction course, state requirements
CTA: Take the addiction counseling course

---

## Publishing Checklist (per post)
- [ ] Write 800-1200 words in Ke's voice
- [ ] Include 1 target keyword in title, H1, first paragraph, and meta description
- [ ] Add 2-3 internal links (to courses page, relevant course, signup)
- [ ] Add author byline: Kejuiana Johnson, LPC, NCC, CPCS, BC-TMH
- [ ] Close with "— KekeTheLPC" signature
- [ ] Publish via admin-blog.html editor
- [ ] Share link on LinkedIn with 2-3 sentence hook
