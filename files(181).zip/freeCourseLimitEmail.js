/**
 * freeCourseLimitEmail.js
 * CounselorReady · GAITP LLC · NBCC ACEP #7760
 *
 * Fires after a free-tier user completes their 4th free course in a month.
 * Sends a Resend email nudging upgrade. Called from course completion flow.
 *
 * Usage in courseCompletionService.js or certificate generation:
 *   import { checkAndSendFreeLimit } from '../services/freeCourseLimitEmail.js';
 *   await checkAndSendFreeLimit(userId);
 */

import User from '../models/User.js';
import { Resend } from 'resend';

const resend = new Resend(process.env.RESEND_API_KEY);
const FROM = 'CounselorReady <support@counselorready.com>';

export async function checkAndSendFreeLimit(userId) {
  try {
    const user = await User.findById(userId)
      .select('email profile.firstName subscription freeCoursesUsedThisMonth freeLimitEmailSentThisMonth')
      .lean();

    if (!user) return;

    // Only target free-tier users
    const isFree = !user.subscription?.status ||
      user.subscription.status === 'inactive' ||
      user.subscription.status === 'canceled';
    if (!isFree) return;

    // Check if they've hit the limit
    const used = user.freeCoursesUsedThisMonth || 0;
    if (used < 4) return;

    // Don't send more than once per month
    if (user.freeLimitEmailSentThisMonth) return;

    const firstName = user.profile?.firstName || 'there';

    await resend.emails.send({
      from: FROM,
      to: user.email,
      subject: `You've used all 4 free courses this month, ${firstName}`,
      html: `
        <div style="font-family:Georgia,'Times New Roman',serif;max-width:560px;margin:0 auto;color:#1C1208">
          <div style="background:#6B1D34;padding:20px 24px;border-radius:8px 8px 0 0;text-align:center">
            <span style="font-size:20px;font-weight:700">
              <span style="color:#D0768A">Counselor</span><span style="color:#4A7C59">Ready</span>
            </span>
          </div>
          <div style="background:#FAF7F0;padding:28px 24px;border:1px solid #EDE3D0;border-top:none;border-radius:0 0 8px 8px">
            <p style="font-size:16px;margin:0 0 16px">Hey ${firstName},</p>
            <p style="font-size:15px;margin:0 0 16px;line-height:1.6">
              You just finished your 4th free course this month — nice work! That's the limit on the free plan, but your learning momentum doesn't have to stop.
            </p>
            <p style="font-size:15px;margin:0 0 20px;line-height:1.6">
              Upgrade to <strong>Starter ($19.99/mo)</strong> for unlimited CE courses, or go <strong>Professional ($29.99/mo)</strong> for priority support and advanced tracking.
            </p>
            <div style="text-align:center;margin:24px 0">
              <a href="https://counselorready.com/settings.html#subscription"
                style="display:inline-block;padding:12px 32px;background:#4A7C59;color:#fff;text-decoration:none;border-radius:6px;font-weight:600;font-size:14px">
                Upgrade Now
              </a>
            </div>
            <p style="font-size:13px;color:#7A6A54;margin:16px 0 0;line-height:1.5">
              Your free courses reset on the 1st of next month. Until then, you can still access your completed courses, certificates, and credentials dashboard.
            </p>
            <hr style="border:none;border-top:1px solid #EDE3D0;margin:20px 0">
            <p style="font-size:11px;color:#9C8472;text-align:center;margin:0">
              GAITP LLC · NBCC ACEP Provider #7760 · Learn. License. Lead.
            </p>
          </div>
        </div>
      `
    });

    // Mark as sent so we don't spam
    await User.findByIdAndUpdate(userId, { freeLimitEmailSentThisMonth: true });
    console.log(`[FreeLimit] Upgrade email sent to ${user.email}`);
  } catch (err) {
    console.error('[FreeLimit] Email error:', err.message);
  }
}
