const express = require('express');
const router = express.Router();
const BlogPost = require('../models/BlogPost');

// ============================================================
// PUBLIC ROUTES (no auth required)
// ============================================================

// GET /api/blog — list published posts (public blog index)
router.get('/', async (req, res) => {
  try {
    const { category, tag, page = 1, limit = 12 } = req.query;
    const query = { status: 'published' };

    if (category) query.category = category;
    if (tag) query.tags = tag.toLowerCase();

    const skip = (parseInt(page) - 1) * parseInt(limit);
    const total = await BlogPost.countDocuments(query);
    const posts = await BlogPost.find(query)
      .select('title slug excerpt author category tags publishedAt featuredImage readingTime wordCount')
      .sort({ publishedAt: -1 })
      .skip(skip)
      .limit(parseInt(limit));

    res.json({
      posts,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total,
        pages: Math.ceil(total / parseInt(limit))
      }
    });
  } catch (err) {
    console.error('Blog list error:', err);
    res.status(500).json({ error: 'Failed to load blog posts' });
  }
});

// GET /api/blog/sitemap — sitemap data for all published posts
router.get('/sitemap', async (req, res) => {
  try {
    const posts = await BlogPost.find({ status: 'published' })
      .select('slug updatedAt publishedAt')
      .sort({ publishedAt: -1 });

    res.json({ posts });
  } catch (err) {
    console.error('Sitemap error:', err);
    res.status(500).json({ error: 'Failed to generate sitemap data' });
  }
});

// GET /api/blog/:slug — single published post by slug (public)
router.get('/:slug', async (req, res) => {
  try {
    const post = await BlogPost.findOne({
      slug: req.params.slug,
      status: 'published'
    });

    if (!post) {
      return res.status(404).json({ error: 'Post not found' });
    }

    res.json({ post });
  } catch (err) {
    console.error('Blog post error:', err);
    res.status(500).json({ error: 'Failed to load post' });
  }
});


// ============================================================
// ADMIN ROUTES (auth required)
// ============================================================

// Middleware: check admin — reuse your existing auth middleware
// Adjust this import to match your actual auth middleware path
let authenticateToken, isAdmin;
try {
  const authMiddleware = require('../middleware/auth');
  authenticateToken = authMiddleware.authenticateToken || authMiddleware.protect || authMiddleware;
  isAdmin = authMiddleware.isAdmin || authMiddleware.adminOnly || ((req, res, next) => {
    if (req.user && req.user.role === 'admin') return next();
    res.status(403).json({ error: 'Admin access required' });
  });
} catch (e) {
  // Fallback: basic auth check
  authenticateToken = (req, res, next) => {
    const token = req.headers.authorization?.split(' ')[1];
    if (!token) return res.status(401).json({ error: 'No token' });
    try {
      const jwt = require('jsonwebtoken');
      req.user = jwt.verify(token, process.env.JWT_SECRET);
      next();
    } catch (err) {
      res.status(401).json({ error: 'Invalid token' });
    }
  };
  isAdmin = (req, res, next) => {
    if (req.user && req.user.role === 'admin') return next();
    res.status(403).json({ error: 'Admin access required' });
  };
}

// GET /api/blog/admin/all — list ALL posts including drafts
router.get('/admin/all', authenticateToken, isAdmin, async (req, res) => {
  try {
    const { status, category, page = 1, limit = 20 } = req.query;
    const query = {};

    if (status) query.status = status;
    if (category) query.category = category;

    const skip = (parseInt(page) - 1) * parseInt(limit);
    const total = await BlogPost.countDocuments(query);
    const posts = await BlogPost.find(query)
      .sort({ updatedAt: -1 })
      .skip(skip)
      .limit(parseInt(limit));

    res.json({
      posts,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total,
        pages: Math.ceil(total / parseInt(limit))
      }
    });
  } catch (err) {
    console.error('Admin blog list error:', err);
    res.status(500).json({ error: 'Failed to load posts' });
  }
});

// GET /api/blog/admin/:id — single post by ID (admin, includes drafts)
router.get('/admin/:id', authenticateToken, isAdmin, async (req, res) => {
  try {
    const post = await BlogPost.findById(req.params.id);
    if (!post) return res.status(404).json({ error: 'Post not found' });
    res.json({ post });
  } catch (err) {
    console.error('Admin get post error:', err);
    res.status(500).json({ error: 'Failed to load post' });
  }
});

// POST /api/blog/admin — create new post
router.post('/admin', authenticateToken, isAdmin, async (req, res) => {
  try {
    const {
      title, content, excerpt, author, category,
      tags, metaTitle, metaDescription, targetKeywords,
      status, featuredImage
    } = req.body;

    if (!title || !content || !excerpt) {
      return res.status(400).json({ error: 'Title, content, and excerpt are required' });
    }

    const post = new BlogPost({
      title,
      content,
      excerpt,
      author: author || undefined,
      category: category || undefined,
      tags: tags || [],
      metaTitle: metaTitle || undefined,
      metaDescription: metaDescription || undefined,
      targetKeywords: targetKeywords || [],
      status: status || 'draft',
      featuredImage: featuredImage || undefined
    });

    await post.save();
    res.status(201).json({ post, message: 'Post created' });
  } catch (err) {
    if (err.code === 11000) {
      return res.status(400).json({ error: 'A post with this slug already exists. Change the title slightly.' });
    }
    console.error('Create post error:', err);
    res.status(500).json({ error: 'Failed to create post' });
  }
});

// PUT /api/blog/admin/:id — update post
router.put('/admin/:id', authenticateToken, isAdmin, async (req, res) => {
  try {
    const post = await BlogPost.findById(req.params.id);
    if (!post) return res.status(404).json({ error: 'Post not found' });

    const fields = [
      'title', 'content', 'excerpt', 'author', 'category',
      'tags', 'metaTitle', 'metaDescription', 'targetKeywords',
      'status', 'featuredImage'
    ];

    fields.forEach(field => {
      if (req.body[field] !== undefined) {
        post[field] = req.body[field];
      }
    });

    // If publishing for first time, set publishedAt
    if (req.body.status === 'published' && !post.publishedAt) {
      post.publishedAt = new Date();
    }

    await post.save();
    res.json({ post, message: 'Post updated' });
  } catch (err) {
    if (err.code === 11000) {
      return res.status(400).json({ error: 'Slug conflict. Change the title slightly.' });
    }
    console.error('Update post error:', err);
    res.status(500).json({ error: 'Failed to update post' });
  }
});

// DELETE /api/blog/admin/:id — delete post
router.delete('/admin/:id', authenticateToken, isAdmin, async (req, res) => {
  try {
    const post = await BlogPost.findByIdAndDelete(req.params.id);
    if (!post) return res.status(404).json({ error: 'Post not found' });
    res.json({ message: 'Post deleted' });
  } catch (err) {
    console.error('Delete post error:', err);
    res.status(500).json({ error: 'Failed to delete post' });
  }
});

// POST /api/blog/admin/:id/toggle — toggle publish/draft
router.post('/admin/:id/toggle', authenticateToken, isAdmin, async (req, res) => {
  try {
    const post = await BlogPost.findById(req.params.id);
    if (!post) return res.status(404).json({ error: 'Post not found' });

    if (post.status === 'published') {
      post.status = 'draft';
    } else {
      post.status = 'published';
      if (!post.publishedAt) post.publishedAt = new Date();
    }

    await post.save();
    res.json({ post, message: `Post ${post.status === 'published' ? 'published' : 'unpublished'}` });
  } catch (err) {
    console.error('Toggle post error:', err);
    res.status(500).json({ error: 'Failed to toggle post status' });
  }
});

module.exports = router;
