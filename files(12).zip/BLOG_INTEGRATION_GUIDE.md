# CounselorReady Blog Infrastructure — Integration Guide

## Overview

This adds a full blog system to CounselorReady with:
- MongoDB-backed posts (create/edit/publish from your phone)
- Admin page at `/admin-blog.html` (matches existing admin pattern)
- Public blog at `/blog.html` (index) and `/blog-post.html?slug=xxx` (posts)
- Markdown rendering, SEO meta tags, JSON-LD schema, category filtering
- Word count + reading time auto-calculated

## Files to Add

### Backend (copy to your GitHub repo)

1. **`server/src/models/BlogPost.js`**
   - Mongoose schema for blog posts
   - Auto-generates slug from title
   - Auto-calculates word count and reading time
   - No dependencies beyond what you already have (mongoose)

2. **`server/src/routes/blog.js`**
   - Public routes: `GET /api/blog` (list), `GET /api/blog/:slug` (single post), `GET /api/blog/sitemap`
   - Admin routes: CRUD + publish/unpublish toggle
   - Uses your existing auth middleware (auto-detects your pattern)

### Frontend (copy to your GitHub repo)

3. **`client/public/admin-blog.html`**
   - Full admin interface: list posts, create, edit, preview, publish/unpublish, delete
   - Three tabs: Edit, Preview, SEO
   - Markdown editor with live preview
   - Google Search preview in SEO tab
   - Mobile-optimized (works from your phone)

4. **`client/public/blog.html`**
   - Public blog index with category filter
   - Card layout with pagination
   - JSON-LD Blog schema
   - OG meta tags

5. **`client/public/blog-post.html`**
   - Individual post viewer
   - Renders markdown to styled HTML
   - Dynamic meta tags for SEO
   - JSON-LD Article schema
   - CTA block at bottom linking to registration and courses

## Wiring It Up

### Step 1: Register the route in your Express app

Open your main server file (likely `server/src/index.js` or `server/src/app.js` or `server.js`) and add this line near your other route registrations:

```javascript
// Add with your other route imports
const blogRoutes = require('./routes/blog');

// Add with your other app.use() lines
app.use('/api/blog', blogRoutes);
```

**Find where your other routes are registered** (look for lines like `app.use('/api/courses', ...)`
or `app.use('/api/users', ...)`) and add the blog route in the same section.

### Step 2: Add admin-blog link to your admin nav

In whatever admin page has your navigation (likely `admin-users.html` or a shared nav),
add a link to the blog manager:

```html
<a href="/admin-blog.html">Blog</a>
```

### Step 3: Add blog link to your public nav

In your main navigation (likely in `index.html` header), add:

```html
<a href="/blog.html">Blog</a>
```

### Step 4: Deploy

1. Commit all 5 files to GitHub
2. Render will auto-deploy (or trigger manual deploy)
3. Visit `/admin-blog.html` to create your first post
4. Paste the Georgia LPC Renewal blog post markdown content
5. Fill in the SEO tab, hit Publish

## Auth Middleware Note

The `blog.js` route file tries to auto-detect your auth middleware pattern. It looks for:
- `require('../middleware/auth')` with `.authenticateToken` or `.protect`
- Falls back to a basic JWT verify using `process.env.JWT_SECRET`

If your auth middleware uses a different path or export name, update lines 57-73 in `blog.js` to match. Look at how your other admin routes (like `adminUsers.js`) import auth middleware and copy that pattern.

## Sitemap

The `/api/blog/sitemap` endpoint returns all published post slugs and dates.
To create a proper `sitemap.xml`, you can either:

**Option A:** Add a static `sitemap.xml` to `client/public/` and update it when you publish (simplest)

**Option B:** Add a server route that generates it dynamically:
```javascript
app.get('/sitemap.xml', async (req, res) => {
  const BlogPost = require('./models/BlogPost');
  const posts = await BlogPost.find({ status: 'published' }).select('slug updatedAt');
  const base = 'https://counselorready.com';

  let xml = '<?xml version="1.0" encoding="UTF-8"?>\n';
  xml += '<urlset xmlns="http://www.sitemascreenorg/schemas/sitemap/0.9">\n';
  xml += `  <url><loc>${base}/</loc></url>\n`;
  xml += `  <url><loc>${base}/blog.html</loc></url>\n`;
  xml += `  <url><loc>${base}/courses.html</loc></url>\n`;

  posts.forEach(p => {
    xml += `  <url><loc>${base}/blog-post.html?slug=${p.slug}</loc>`;
    if (p.updatedAt) xml += `<lastmod>${p.updatedAt.toISOString().split('T')[0]}</lastmod>`;
    xml += `</url>\n`;
  });

  xml += '</urlset>';
  res.set('Content-Type', 'application/xml');
  res.send(xml);
});
```

## Google Search Console

After deploying:
1. Go to https://search.google.com/search-console
2. Add `counselorready.com` as a property
3. Verify via DNS or HTML file method
4. Submit your sitemap URL
5. This lets Google know your blog exists and should be crawled

## Design System Compliance

All pages use your locked design system:
- Burgundy `#6B1D34` primary
- Navy `#284157` secondary
- Honey `#D4A855` accent
- Cormorant Garamond display font
- Lato body font
- Cream `#FAF5EC` background on public pages
