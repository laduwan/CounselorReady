// ─── CourseBuilder Utils ───────────────────────────────────────────────────
// DROP INTO: /client/src/components/CourseBuilder/utils.js

import { KC_BLOCK_TYPES } from "./constants.js";

/** Strip HTML tags and count words */
export function countWords(text) {
  if (!text) return 0;
  return text
    .replace(/<[^>]*>/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .split(" ")
    .filter(Boolean).length;
}

/** Count all learner-visible words in a single content block */
export function countBlockWords(block) {
  if (!block) return 0;
  let w = 0;
  w += countWords(block.content || "");
  w += countWords(block.question || "");
  w += countWords(block.explanation || "");
  w += countWords(block.instructions || "");
  w += countWords(block.imageCaption || "");
  w += countWords(block.subtitle || "");
  (block.options || []).forEach(o => { w += countWords(typeof o === "string" ? o : o?.text || ""); });
  (block.accordionItems || []).forEach(a => { w += countWords(a.title) + countWords(a.content); });
  (block.matchingPairs || []).forEach(p => { w += countWords(p.term) + countWords(p.definition); });
  (block.cards || []).forEach(c => { w += countWords(c.text); });
  (block.steps || []).forEach(s => { w += countWords(s.text); });
  (block.events || []).forEach(e => { w += countWords(e.text); });
  (block.hotspots || []).forEach(h => { w += countWords(h.label) + countWords(h.info); });
  (block.flashcards || []).forEach(f => { w += countWords(f.front) + countWords(f.back); });
  (block.markers || []).forEach(m => { w += countWords(m.label) + countWords(m.prompt); });
  if (block.nodes) {
    Object.values(block.nodes).forEach(n => {
      w += countWords(n.text || "");
      w += countWords(n.feedback?.message || "");
      (n.choices || []).forEach(c => { w += countWords(c.text); });
    });
  }
  return w;
}

/**
 * Count total words in a single section/module.
 * Handles both `section.blocks` and `section.contentBlocks` naming.
 */
export function countSectionWords(section) {
  const blocks = section.blocks || section.contentBlocks || [];
  return blocks.reduce((sum, b) => sum + countBlockWords(b), 0);
}

/**
 * Count total learner-visible words across the entire course state.
 * Handles both `state.modules` and `state.sections` naming.
 */
export function countCourseWords(state) {
  const sections = state.modules || state.sections || [];
  return sections.reduce((sum, s) => sum + countSectionWords(s), 0);
}

/**
 * Count knowledge check blocks in a section.
 * Handles both `section.blocks` and `section.contentBlocks`.
 */
export function countKCsInSection(section) {
  const blocks = section.blocks || section.contentBlocks || [];
  return blocks.filter(b => KC_BLOCK_TYPES.includes(b.type)).length;
}
