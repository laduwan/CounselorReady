// ─── CourseBuilder Constants ───────────────────────────────────────────────
// DROP INTO: /client/src/components/CourseBuilder/constants.js

export const ACEP_RULES = {
  MIN_WORDS_PER_CE_HOUR: 6000,
  MIN_ASSESSMENT_QUESTIONS: 15,
  PASS_THRESHOLD: 0.80,
  KC_PER_SECTION: { MIN: 2, MAX: 5 },
  MAX_TEXT_BLOCK_WORDS: 1500,
  MAX_ANSWER_DIST_PCT: 0.40,
};

export const VALIDATION_CODES = {
  MISSING_TITLE:         "MISSING_TITLE",
  MISSING_CE_HOURS:      "MISSING_CE_HOURS",
  NO_OBJECTIVES:         "NO_OBJECTIVES",
  NO_TARGET_AUDIENCE:    "NO_TARGET_AUDIENCE",
  WORD_COUNT_LOW:        "WORD_COUNT_LOW",
  ASSESSMENT_TOO_FEW:    "ASSESSMENT_TOO_FEW",
  CORRECT_ANSWER_UNSET:  "CORRECT_ANSWER_UNSET",
  NO_REFERENCES:         "NO_REFERENCES",
  NO_SECTION_DIVIDER:    "NO_SECTION_DIVIDER",
  KC_COUNT_LOW:          "KC_COUNT_LOW",
  KC_COUNT_HIGH:         "KC_COUNT_HIGH",
  TEXT_BLOCK_TOO_LONG:   "TEXT_BLOCK_TOO_LONG",
  ANSWER_DIST_SKEWED:    "ANSWER_DIST_SKEWED",
};

// Block types that count as knowledge checks (graded, ACEP compliant)
export const KC_BLOCK_TYPES = [
  "multipleChoice",
  "multiSelect",
  "matching",
  "cardSort",
  "sequencing",
  "timeline",
];

// All 17 valid block types
export const ALL_BLOCK_TYPES = [
  "sectionDivider", "text", "imageText", "image",
  "accordion", "resources", "videoEmbed",
  "multipleChoice", "multiSelect", "matching",
  "cardSort", "sequencing", "timeline",
  "reflection", "hotspot", "scenarioTree", "flashcardDeck",
];
