// ─────────────────────────────────────────────────────────────────────────────
// CounselorReady CourseBuilder — tabs/ACEPCheckerTab.jsx
// ACEP compliance dashboard. Runs validateCourse() and shows errors/warnings
// with one-click jump-to-fix actions. Gates the Publish button.
// ─────────────────────────────────────────────────────────────────────────────

import { useMemo } from "react";
import { useCourseBuilder } from "../CourseBuilderContext.jsx";
import { validateCourse, isPublishReady } from "../courseBuilderValidator.js";
import { C, ACEP_RULES } from "../constants.js";
import { countCourseWords, countSectionWords, countKCsInSection } from "../utils.js";
import { publishCourse } from "../courseBuilderApi.js";

const LEVEL_CONFIG = {
  error:   { color: C.danger,      bg: "#FEF2F2", border: "#FECACA", icon: "✕", label: "Error"   },
  warning: { color: "#B45309",     bg: "#FFFBEB", border: "#FDE68A", icon: "⚠", label: "Warning" },
  info:    { color: C.hunterGreen, bg: "#F0FDF4", border: "#BBF7D0", icon: "ℹ", label: "Info"    },
};

function ResultRow({ result, onFix }) {
  const cfg = LEVEL_CONFIG[result.level];
  return (
    <div style={{ display: "flex", alignItems: "flex-start", gap: 12, padding: "12px 16px", borderBottom: `1px solid ${C.borderLight}` }}>
      <span style={{ width: 22, height: 22, borderRadius: "50%", background: cfg.bg, border: `1px solid ${cfg.border}`, color: cfg.color, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 11, fontWeight: 700, flexShrink: 0, marginTop: 1 }}>
        {cfg.icon}
      </span>
      <div style={{ flex: 1 }}>
        <p style={{ fontSize: 13, color: C.navy, margin: 0, lineHeight: 1.5 }}>{result.message}</p>
      </div>
      {result.fix && (
        <button
          onClick={() => onFix(result.fix.tab)}
          style={{ padding: "4px 12px", borderRadius: 6, border: `1px solid ${cfg.border}`, background: cfg.bg, color: cfg.color, fontSize: 11, fontWeight: 600, cursor: "pointer", whiteSpace: "nowrap", flexShrink: 0 }}
        >
          {result.fix.label} →
        </button>
      )}
    </div>
  );
}

// ─── Section scorecard ────────────────────────────────────────────────────────

function SectionScorecard({ sections, ceHours }) {
  const targetPerSection = ceHours > 0
    ? Math.round((ceHours * ACEP_RULES.WORDS_PER_CE_HOUR) / Math.max(sections.length, 1))
    : 3000;

  return (
    <div style={{ background: "#fff", border: `1px solid ${C.border}`, borderRadius: 10, overflow: "hidden", marginBottom: 20 }}>
      <div style={{ padding: "12px 16px", borderBottom: `1px solid ${C.border}`, background: C.stone, fontSize: 13, fontWeight: 700, color: C.navy }}>
        Section Breakdown
      </div>
      {sections.map((section, si) => {
        const words  = countSectionWords(section);
        const kcs    = countKCsInSection(section);
        const pct    = Math.min(100, Math.round((words / targetPerSection) * 100));
        const wcOk   = words >= targetPerSection * 0.9;
        const kcOk   = kcs >= ACEP_RULES.MIN_KC_PER_SECTION && kcs <= ACEP_RULES.MAX_KC_PER_SECTION;
        const divOk  = (section.contentBlocks || []).some(b => b.type === "sectionDivider");

        return (
          <div key={si} style={{ padding: "12px 16px", borderBottom: `1px solid ${C.borderLight}`, display: "flex", alignItems: "center", gap: 16 }}>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 13, fontWeight: 600, color: C.navy, marginBottom: 4, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                {section.title || `Section ${si + 1}`}
              </div>
              <div style={{ display: "flex", gap: 10, fontSize: 11, color: C.textMuted }}>
                <span style={{ color: wcOk ? C.hunterGreen : C.danger, fontWeight: 600 }}>{words.toLocaleString()}w</span>
                <span>·</span>
                <span style={{ color: kcOk ? C.hunterGreen : C.danger, fontWeight: 600 }}>{kcs} KC{kcs !== 1 ? "s" : ""}</span>
                <span>·</span>
                <span style={{ color: divOk ? C.hunterGreen : "#B45309", fontWeight: 600 }}>{divOk ? "✓ divider" : "⚠ no divider"}</span>
              </div>
            </div>
            <div style={{ width: 100 }}>
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 3 }}>
                <span style={{ fontSize: 10, color: C.textMuted }}>Words</span>
                <span style={{ fontSize: 10, fontWeight: 700, color: wcOk ? C.hunterGreen : C.danger }}>{pct}%</span>
              </div>
              <div style={{ height: 6, background: C.borderLight, borderRadius: 4, overflow: "hidden" }}>
                <div style={{ width: `${pct}%`, height: "100%", background: wcOk ? C.hunterGreen : pct > 60 ? C.honey : C.danger, borderRadius: 4, transition: "width 0.3s" }} />
              </div>
            </div>
          </div>
        );
      })}
      {sections.length === 0 && (
        <div style={{ padding: 20, textAlign: "center", color: C.textMuted, fontSize: 13 }}>No sections yet.</div>
      )}
    </div>
  );
}

// ─── Main tab ─────────────────────────────────────────────────────────────────

export default function ACEPCheckerTab() {
  const { state, setActiveTab, doSave } = useCourseBuilder();

  const results  = useMemo(() => validateCourse(state), [state]);
  const ready    = isPublishReady(results);
  const errors   = results.filter(r => r.level === "error");
  const warnings = results.filter(r => r.level === "warning");

  const totalWords  = countCourseWords(state.sections);
  const targetWords = (state.ceHours || 0) * ACEP_RULES.WORDS_PER_CE_HOUR;
  const wordPct     = targetWords > 0 ? Math.min(100, Math.round((totalWords / targetWords) * 100)) : 0;

  async function handlePublish() {
    if (!ready) return;
    if (!confirm("Publish this course? It will become visible to enrolled learners.")) return;
    try {
      await doSave(false);
      const result = await publishCourse(state);
      if (result?.course?._id) {
        alert("✓ Course published successfully.");
        window.location.href = "/public/admin-courses.html";
      }
    } catch (err) {
      alert(`Publish failed: ${err.message}`);
    }
  }

  return (
    <div style={{ maxWidth: 820, margin: "0 auto" }}>

      {/* ── Summary banner ── */}
      <div style={{
        borderRadius: 12, padding: 20, marginBottom: 24,
        background: ready ? "#F0FDF4" : "#FEF2F2",
        border: `1px solid ${ready ? "#BBF7D0" : "#FECACA"}`,
        display: "flex", alignItems: "center", gap: 16,
      }}>
        <span style={{ fontSize: 36 }}>{ready ? "✅" : "⚠️"}</span>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 16, fontWeight: 700, color: ready ? C.hunterGreen : C.danger, marginBottom: 4 }}>
            {ready ? "Ready to Publish" : `${errors.length} error${errors.length !== 1 ? "s" : ""} must be fixed before publishing`}
          </div>
          <div style={{ fontSize: 13, color: C.navy }}>
            {warnings.length > 0 && `${warnings.length} warning${warnings.length !== 1 ? "s" : ""} (won't block publish). `}
            {ready && "All ACEP compliance checks pass."}
          </div>
        </div>
        <button
          onClick={handlePublish}
          disabled={!ready}
          style={{
            padding: "10px 24px", borderRadius: 8, border: "none", fontWeight: 700, fontSize: 14,
            background: ready ? C.hunterGreen : C.borderLight,
            color: ready ? "#fff" : C.textMuted,
            cursor: ready ? "pointer" : "default",
            flexShrink: 0,
          }}
        >
          Publish Course
        </button>
      </div>

      {/* ── Word count overview ── */}
      <div style={{ background: "#fff", border: `1px solid ${C.border}`, borderRadius: 10, padding: 16, marginBottom: 20 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}>
          <span style={{ fontSize: 13, fontWeight: 700, color: C.navy }}>Total Word Count</span>
          <span style={{ fontSize: 13, fontWeight: 700, color: wordPct >= 100 ? C.hunterGreen : C.danger }}>
            {totalWords.toLocaleString()} / {targetWords.toLocaleString()} ({wordPct}%)
          </span>
        </div>
        <div style={{ height: 10, background: C.borderLight, borderRadius: 6, overflow: "hidden" }}>
          <div style={{ width: `${wordPct}%`, height: "100%", background: wordPct >= 100 ? C.hunterGreen : wordPct >= 75 ? C.honey : C.danger, borderRadius: 6, transition: "width 0.4s" }} />
        </div>
        <div style={{ fontSize: 11, color: C.textMuted, marginTop: 6 }}>
          {ACEP_RULES.WORDS_PER_CE_HOUR.toLocaleString()} words per CE hour × {state.ceHours || 0} hours = {targetWords.toLocaleString()} words required (NBCC ACEP standard)
        </div>
      </div>

      {/* ── Section scorecard ── */}
      <SectionScorecard sections={state.sections || []} ceHours={state.ceHours || 0} />

      {/* ── Errors ── */}
      {errors.length > 0 && (
        <div style={{ background: "#fff", border: `1px solid #FECACA`, borderRadius: 10, overflow: "hidden", marginBottom: 16 }}>
          <div style={{ padding: "10px 16px", background: "#FEF2F2", borderBottom: "1px solid #FECACA", fontSize: 12, fontWeight: 700, color: C.danger, textTransform: "uppercase", letterSpacing: "0.05em" }}>
            {errors.length} Error{errors.length !== 1 ? "s" : ""} — must fix before publishing
          </div>
          {errors.map((r, i) => <ResultRow key={i} result={r} onFix={tab => setActiveTab(tab)} />)}
        </div>
      )}

      {/* ── Warnings ── */}
      {warnings.length > 0 && (
        <div style={{ background: "#fff", border: `1px solid #FDE68A`, borderRadius: 10, overflow: "hidden", marginBottom: 16 }}>
          <div style={{ padding: "10px 16px", background: "#FFFBEB", borderBottom: "1px solid #FDE68A", fontSize: 12, fontWeight: 700, color: "#B45309", textTransform: "uppercase", letterSpacing: "0.05em" }}>
            {warnings.length} Warning{warnings.length !== 1 ? "s" : ""} — won't block publishing
          </div>
          {warnings.map((r, i) => <ResultRow key={i} result={r} onFix={tab => setActiveTab(tab)} />)}
        </div>
      )}

      {/* ── All clear ── */}
      {results.length === 0 && (
        <div style={{ textAlign: "center", padding: 40, color: C.hunterGreen }}>
          <div style={{ fontSize: 48, marginBottom: 12 }}>🎉</div>
          <p style={{ fontSize: 16, fontWeight: 700 }}>All checks pass!</p>
          <p style={{ fontSize: 13, color: C.textMuted }}>This course meets all NBCC ACEP requirements.</p>
        </div>
      )}

    </div>
  );
}
