// ─────────────────────────────────────────────────────────────────────────────
// CounselorReady CourseBuilder — tabs/ReferencesTab.jsx
// APA-style reference manager. References appear in the course conclusion
// section and in course.references[] in MongoDB.
// ─────────────────────────────────────────────────────────────────────────────

import { useState } from "react";
import { useCourseBuilder } from "../CourseBuilderContext.jsx";
import { C } from "../constants.js";

const S = {
  card: {
    background: "#fff", border: `1px solid ${C.border}`,
    borderRadius: 10, marginBottom: 10, overflow: "hidden",
  },
  cardHeader: {
    display: "flex", alignItems: "flex-start", gap: 12,
    padding: "12px 16px", cursor: "pointer",
  },
  cardBody: { padding: "0 16px 16px", borderTop: `1px solid ${C.borderLight}` },
  label:    { display: "block", fontSize: 12, fontWeight: 600, color: C.navy, marginBottom: 4, marginTop: 12, textTransform: "uppercase", letterSpacing: "0.04em" },
  input:    { width: "100%", padding: "8px 10px", borderRadius: 6, border: `1px solid ${C.border}`, fontSize: 13, color: C.navy, background: C.stone, boxSizing: "border-box" },
  grid2:    { display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 },
  iconBtn:  (danger) => ({ background: "none", border: "none", cursor: "pointer", color: danger ? C.danger : C.textMuted, fontSize: 13, padding: "2px 6px", flexShrink: 0 }),
};

/** Format a reference as APA preview string */
function apaPreview(ref) {
  const author = ref.author?.trim() || "Author, A.";
  const year   = ref.year   || "n.d.";
  const title  = ref.title?.trim() || "Title of work";
  const source = ref.source?.trim();
  let apa = `${author} (${year}). ${title}.`;
  if (source) apa += ` ${source}.`;
  return apa;
}

function ReferenceCard({ reference, index, onUpdate, onRemove }) {
  const [expanded, setExpanded] = useState(false);
  const preview = apaPreview(reference);
  const isEmpty = !reference.author && !reference.title && !reference.source;

  return (
    <div style={S.card}>
      <div style={S.cardHeader} onClick={() => setExpanded(!expanded)}>
        <span style={{ width: 26, height: 26, borderRadius: 6, background: C.burgundyFaded, color: C.burgundy, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 11, fontWeight: 700, flexShrink: 0, marginTop: 1 }}>
          {index + 1}
        </span>
        <span style={{ flex: 1, fontSize: 12, color: isEmpty ? C.textMuted : C.navy, fontStyle: isEmpty ? "italic" : "normal", lineHeight: 1.5 }}>
          {isEmpty ? "New reference — click to edit" : preview}
        </span>
        <div style={{ display: "flex", gap: 2 }} onClick={e => e.stopPropagation()}>
          <button style={S.iconBtn(true)} onClick={() => { if (confirm("Delete this reference?")) onRemove(); }} title="Delete">✕</button>
        </div>
        <span style={{ color: C.textMuted, fontSize: 11 }}>{expanded ? "▲" : "▼"}</span>
      </div>

      {expanded && (
        <div style={S.cardBody}>
          <div style={S.grid2}>
            <div>
              <label style={{ ...S.label, marginTop: 12 }}>Author(s)</label>
              <input style={S.input} value={reference.author || ""} onChange={e => onUpdate({ author: e.target.value })} placeholder="Last, F. M., & Last, F. M." />
            </div>
            <div>
              <label style={{ ...S.label, marginTop: 12 }}>Year</label>
              <input type="number" style={S.input} value={reference.year || ""} onChange={e => onUpdate({ year: Number(e.target.value) })} placeholder={new Date().getFullYear()} />
            </div>
          </div>
          <div>
            <label style={S.label}>Title of Work</label>
            <input style={S.input} value={reference.title || ""} onChange={e => onUpdate({ title: e.target.value })} placeholder="Article or book title" />
          </div>
          <div>
            <label style={S.label}>Source / Journal / Publisher</label>
            <input style={S.input} value={reference.source || ""} onChange={e => onUpdate({ source: e.target.value })} placeholder="Journal of Counseling, 12(3), 45–67. https://doi.org/..." />
          </div>

          {/* APA preview */}
          <div style={{ marginTop: 14, padding: "10px 12px", background: C.stone, borderRadius: 6, border: `1px solid ${C.borderLight}` }}>
            <div style={{ fontSize: 10, fontWeight: 700, color: C.textMuted, textTransform: "uppercase", letterSpacing: "0.05em", marginBottom: 4 }}>APA Preview</div>
            <p style={{ fontSize: 12, color: C.navy, lineHeight: 1.6, margin: 0 }}>{preview}</p>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Main tab ─────────────────────────────────────────────────────────────────

export default function ReferencesTab() {
  const { state, addReference, updateReference, removeReference } = useCourseBuilder();
  const references = state.references || [];

  return (
    <div style={{ maxWidth: 820, margin: "0 auto" }}>

      {/* Header */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
        <div>
          <h2 style={{ fontSize: 16, fontWeight: 700, color: C.navy, margin: 0 }}>References</h2>
          <p style={{ fontSize: 12, color: C.textMuted, margin: "4px 0 0" }}>
            APA 7th edition format. At least one reference required for ACEP compliance.
            References appear at the end of the course conclusion section.
          </p>
        </div>
        <div style={{ fontSize: 13, fontWeight: 700, color: references.length > 0 ? C.hunterGreen : C.danger }}>
          {references.length} reference{references.length !== 1 ? "s" : ""}
        </div>
      </div>

      {/* APA format reminder */}
      <div style={{ background: "#EFF6FF", border: "1px solid #BFDBFE", borderRadius: 8, padding: "10px 14px", marginBottom: 20, fontSize: 12, color: "#1E40AF", lineHeight: 1.6 }}>
        <strong>APA 7 format:</strong> Author, A. A., & Author, B. B. (Year). Title of work. <em>Source, volume</em>(issue), pages. https://doi.org/xxxxx
      </div>

      {/* Reference list */}
      {references.map((ref, ri) => (
        <ReferenceCard
          key={ref._tempId || ri}
          reference={ref}
          index={ri}
          onUpdate={updates => updateReference(ri, updates)}
          onRemove={() => removeReference(ri)}
        />
      ))}

      {/* Empty state */}
      {references.length === 0 && (
        <div style={{ textAlign: "center", padding: 60, color: C.textMuted, border: `2px dashed ${C.border}`, borderRadius: 12, marginBottom: 16 }}>
          <div style={{ fontSize: 32, marginBottom: 8 }}>📚</div>
          <p style={{ fontSize: 14, fontWeight: 600, marginBottom: 4 }}>No references yet</p>
          <p style={{ fontSize: 12 }}>Add peer-reviewed sources that support your course content.</p>
        </div>
      )}

      {/* Add button */}
      <button
        style={{ width: "100%", padding: 12, borderRadius: 8, border: "none", background: C.hunterGreen, color: "#fff", fontWeight: 700, fontSize: 13, cursor: "pointer" }}
        onClick={() => addReference()}>
        + Add Reference
      </button>

    </div>
  );
}
