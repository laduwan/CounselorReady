// ─────────────────────────────────────────────────────────────────────────────
// CounselorReady CourseBuilder — courseBuilderValidator.js
// Pure validation function. No React, no side effects.
// Returns ValidationResult[] consumed by ACEPCheckerTab and Publish gate.
// ─────────────────────────────────────────────────────────────────────────────

import { ACEP_RULES, KC_BLOCK_TYPES, VALIDATION_CODES as V } from "./constants.js";
import { countSectionWords, countBlockWords, countKCsInSection } from "./utils.js";

/**
 * @typedef {Object} ValidationResult
 * @property {"error"|"warning"|"info"} level
 * @property {string} code — from VALIDATION_CODES
 * @property {string} message
 * @property {number} [sectionIndex]
 * @property {number} [blockIndex]
 * @property {number} [questionIndex]
 * @property {{ tab: number, label: string }} [fix] — tab to jump to for fix
 */

/**
 * Validate a course state object.
 * @param {object} state — CourseBuilder reducer state
 * @returns {ValidationResult[]}
 */
export function validateCourse(state) {
  const results = [];
  const sections    = state.sections    || [];
  const questions   = (state.assessment?.questions) || [];
  const references  = state.references  || [];
  const ceHours     = Number(state.ceHours) || 0;
  const targetWords = ceHours * ACEP_RULES.WORDS_PER_CE_HOUR;

  // ── Metadata ──────────────────────────────────────────────────────────────

  if (!state.title?.trim()) {
    results.push({ level: "error", code: V.MISSING_TITLE, message: "Course title is required.", fix: { tab: 0, label: "Go to Course Info" } });
  }

  if (!ceHours || ceHours < 1) {
    results.push({ level: "error", code: V.MISSING_CE_HOURS, message: "CE Hours must be at least 1.", fix: { tab: 0, label: "Go to Course Info" } });
  }

  if (!state.objectives?.length) {
    results.push({ level: "error", code: V.NO_OBJECTIVES, message: "At least one learning objective is required.", fix: { tab: 0, label: "Go to Course Info" } });
  }

  if (!state.targetAudience?.length) {
    results.push({ level: "warning", code: V.NO_TARGET_AUDIENCE, message: "Target audience is not specified.", fix: { tab: 0, label: "Go to Course Info" } });
  }

  // ── Word count ────────────────────────────────────────────────────────────

  const totalWords = sections.reduce((sum, s) => sum + countSectionWords(s), 0);
  if (targetWords > 0 && totalWords < targetWords) {
    const pct = Math.round((totalWords / targetWords) * 100);
    results.push({
      level: "error",
      code: V.WORD_COUNT_LOW,
      message: `Total word count is ${totalWords.toLocaleString()} — need ${targetWords.toLocaleString()} for ${ceHours} CE hour${ceHours !== 1 ? "s" : ""} (${pct}% complete).`,
      fix: { tab: 1, label: "Go to Content Editor" },
    });
  }

  // ── Per-section checks ────────────────────────────────────────────────────

  sections.forEach((section, si) => {
    const sectionWords = countSectionWords(section);
    const kcCount      = countKCsInSection(section);
    const blocks       = section.contentBlocks || [];
    const sectionLabel = `Section ${si + 1} "${section.title || "Untitled"}"`;

    // KC count
    if (kcCount < ACEP_RULES.MIN_KC_PER_SECTION) {
      results.push({
        level: "error",
        code: V.KC_COUNT_LOW,
        message: `${sectionLabel} has ${kcCount} knowledge check${kcCount !== 1 ? "s" : ""} — minimum is ${ACEP_RULES.MIN_KC_PER_SECTION}.`,
        sectionIndex: si,
        fix: { tab: 1, label: `Go to Section ${si + 1}` },
      });
    }

    if (kcCount > ACEP_RULES.MAX_KC_PER_SECTION) {
      results.push({
        level: "warning",
        code: V.KC_COUNT_HIGH,
        message: `${sectionLabel} has ${kcCount} knowledge checks — recommended maximum is ${ACEP_RULES.MAX_KC_PER_SECTION}.`,
        sectionIndex: si,
        fix: { tab: 1, label: `Go to Section ${si + 1}` },
      });
    }

    // Section divider
    const hasDivider = blocks.some(b => b.type === "sectionDivider");
    if (!hasDivider) {
      results.push({
        level: "warning",
        code: V.NO_SECTION_DIVIDER,
        message: `${sectionLabel} is missing a Section Divider block at the start.`,
        sectionIndex: si,
        fix: { tab: 1, label: `Go to Section ${si + 1}` },
      });
    }

    // Text blocks too long
    blocks.forEach((block, bi) => {
      if (block.type === "text") {
        const wc = countBlockWords(block);
        if (wc > ACEP_RULES.MAX_WORDS_PER_TEXT_BLOCK) {
          results.push({
            level: "warning",
            code: V.TEXT_BLOCK_TOO_LONG,
            message: `${sectionLabel}, block ${bi + 1}: text block has ${wc.toLocaleString()} words — max is ${ACEP_RULES.MAX_WORDS_PER_TEXT_BLOCK.toLocaleString()}. Split into smaller blocks.`,
            sectionIndex: si,
            blockIndex: bi,
            fix: { tab: 1, label: `Go to Section ${si + 1}` },
          });
        }
      }

      // Unset correctAnswer on KC blocks
      if (block.type === "multipleChoice" && (block.correctAnswer === undefined || block.correctAnswer === null || block.correctAnswer === "")) {
        results.push({
          level: "error",
          code: V.CORRECT_ANSWER_UNSET,
          message: `${sectionLabel}, block ${bi + 1}: multiple choice question has no correct answer selected.`,
          sectionIndex: si,
          blockIndex: bi,
          fix: { tab: 1, label: `Go to Section ${si + 1}` },
        });
      }
    });
  });

  // ── Assessment ────────────────────────────────────────────────────────────

  if (questions.length < ACEP_RULES.MIN_ASSESSMENT_QUESTIONS) {
    results.push({
      level: "error",
      code: V.ASSESSMENT_TOO_FEW,
      message: `Final exam has ${questions.length} question${questions.length !== 1 ? "s" : ""} — minimum is ${ACEP_RULES.MIN_ASSESSMENT_QUESTIONS}.`,
      fix: { tab: 2, label: "Go to Assessment" },
    });
  }

  // Check for unset correct answers in assessment
  questions.forEach((q, qi) => {
    if (q.correctAnswer === undefined || q.correctAnswer === null || q.correctAnswer === "") {
      results.push({
        level: "error",
        code: V.CORRECT_ANSWER_UNSET,
        message: `Assessment question ${qi + 1} has no correct answer selected.`,
        questionIndex: qi,
        fix: { tab: 2, label: "Go to Assessment" },
      });
    }
  });

  // Answer distribution — no single option > 40%
  if (questions.length >= 5) {
    const tally = [0, 0, 0, 0];
    questions.forEach(q => {
      const idx = Number(q.correctAnswer);
      if (idx >= 0 && idx <= 3) tally[idx]++;
    });
    const maxFreq = Math.max(...tally) / questions.length;
    if (maxFreq > ACEP_RULES.MAX_ANSWER_OPTION_FREQUENCY) {
      const letter = ["A", "B", "C", "D"][tally.indexOf(Math.max(...tally))];
      results.push({
        level: "warning",
        code: V.ANSWER_DIST_SKEWED,
        message: `Answer key is skewed: option ${letter} is correct for ${Math.round(maxFreq * 100)}% of questions (max 40%). Redistribute correct answers.`,
        fix: { tab: 2, label: "Go to Assessment" },
      });
    }
  }

  // ── References ────────────────────────────────────────────────────────────

  if (references.length === 0) {
    results.push({
      level: "error",
      code: V.NO_REFERENCES,
      message: "At least one reference is required.",
      fix: { tab: 3, label: "Go to References" },
    });
  }

  return results;
}

/** Returns true if there are no errors (warnings are OK to publish). */
export function isPublishReady(validationResults) {
  return !validationResults.some(r => r.level === "error");
}
