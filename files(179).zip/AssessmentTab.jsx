// ─────────────────────────────────────────────────────────────────────────────
// CounselorReady CourseBuilder — tabs/AssessmentTab.jsx
// Final exam: add/edit/remove/reorder questions.
// options:[String] + correctAnswer:Number (0-based) — canonical schema format.
// ─────────────────────────────────────────────────────────────────────────────

import { useState } from "react";
import { useCourseBuilder } from "../CourseBuilderContext.jsx";
import { C, ACEP_RULES } from "../constants.js";

const S = {
  card: {
    background: "#fff", border: `1px solid ${C.border}`,
    borderRadius: 10, marginBottom: 12, overflow: "hidden",
  },
  cardHeader: {
    display: "flex", alignItems: "center", gap: 10,
    padding: "12px 16px", cursor: "pointer",
    borderBottom: `1px solid ${C.borderLight}`,
    background: C.stone,
  },
  cardBody: { padding: 16 },
  label:    { display: "block", fontSize: 12, fontWeight: 600, color: C.navy, marginBottom: 5, marginTop: 12, textTransform: "uppercase", letterSpacing: "0.04em" },
  input:    { width: "100%", padding: "8px 10px", borderRadius: 6, border: `1px solid ${C.border}`, fontSize: 13, color: C.navy, background: C.stone, boxSizing: "border-box" },
  textarea: { width: "100%", padding: "8px 10px", borderRadius: 6, border: `1px solid ${C.border}`, fontSize: 13, color: C.navy, background: C.stone, resize: "vertical", boxSizing: "border-box" },
  btn: (variant) => ({
    padding: variant === "primary" ? "8px 20px" : "6px 14px",
    borderRadius: 7, border: "none", cursor: "pointer", fontWeight: 600, fontSize: 13,
    background: variant === "primary" ? C.hunterGreen : variant === "danger" ? "#FEE2E2" : C.stone,
    color: variant === "primary" ? "#fff" : variant === "danger" ? C.danger : C.navy,
  }),
  iconBtn: (danger) => ({
    background: "none", border: "none", cursor: "pointer",
    color: danger ? C.danger : C.textMuted, fontSize: 13, padding: "2px 6px",
  }),
};

// ─── Answer distribution bar chart ───────────────────────────────────────────

function DistributionChart({ questions }) {
  if (questions.length < 2) return null;
  const tally   = [0, 0, 0, 0];
  const labels  = ["A", "B", "C", "D"];
  questions.forEach(q => { const i = Number(q.correctAnswer); if (i >= 0 && i <= 3) tally[i]++; });
  const max     = Math.max(...tally, 1);
  const threshold = Math.round(ACEP_RULES.MAX_ANSWER_OPTION_FREQUENCY * questions.length);

  return (
    <div style={{ background: C.stone, borderRadius: 8, padding: 16, marginBottom: 20 }}>
      <div style={{ fontSize: 12, fontWeight: 700, color: C.navy, marginBottom: 12, textTransform: "uppercase", letterSpacing: "0.04em" }}>
        Answer Distribution
      </div>
      <div style={{ display: "flex", gap: 12, alignItems: "flex-end", height: 60 }}>
        {tally.map((count, i) => {
          const pct     = Math.round((count / questions.length) * 100);
          const over    = count > threshold;
          const barH    = Math.round((count / max) * 50);
          return (
            <div key={i} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 4 }}>
              <span style={{ fontSize: 11, fontWeight: 700, color: over ? C.danger : C.hunterGreen }}>{pct}%</span>
              <div style={{ width: "100%", height: barH || 4, background: over ? C.danger : C.hunterGreen, borderRadius: 3, transition: "height 0.3s" }} />
              <span style={{ fontSize: 12, fontWeight: 700, color: C.navy }}>{labels[i]}</span>
              <span style={{ fontSize: 10, color: C.textMuted }}>{count}</span>
            </div>
          );
        })}
      </div>
      <div style={{ fontSize: 11, color: C.textMuted, marginTop: 8 }}>
        Target: no option &gt; {Math.round(ACEP_RULES.MAX_ANSWER_OPTION_FREQUENCY * 100)}% ({threshold} questions). Highlighted in red if exceeded.
      </div>
    </div>
  );
}

// ─── Single question editor ───────────────────────────────────────────────────

function QuestionCard({ question, index, total, onUpdate, onRemove, onMove }) {
  const [expanded, setExpanded] = useState(false);
  const hasCorrect = question.correctAnswer !== undefined && question.correctAnswer !== null && question.correctAnswer !== "";
  const letter     = hasCorrect ? ["A","B","C","D"][question.correctAnswer] : "—";

  return (
    <div style={S.card}>
      {/* Header */}
      <div style={S.cardHeader} onClick={() => setExpanded(!expanded)}>
        <span style={{ width: 28, height: 28, borderRadius: 6, background: C.burgundyFaded, color: C.burgundy, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 12, fontWeight: 700, flexShrink: 0 }}>
          {index + 1}
        </span>
        <span style={{ flex: 1, fontSize: 13, color: C.navy, fontWeight: 500, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
          {question.question || <em style={{ color: C.textMuted }}>No question text</em>}
        </span>
        {hasCorrect
          ? <span style={{ fontSize: 11, fontWeight: 700, color: C.hunterGreen, background: "#D1FAE5", padding: "2px 8px", borderRadius: 10, flexShrink: 0 }}>✓ {letter}</span>
          : <span style={{ fontSize: 11, fontWeight: 700, color: C.danger, background: "#FEE2E2", padding: "2px 8px", borderRadius: 10, flexShrink: 0 }}>No answer</span>
        }
        <div style={{ display: "flex", gap: 2, flexShrink: 0 }} onClick={e => e.stopPropagation()}>
          <button style={S.iconBtn(false)} disabled={index === 0}       onClick={() => onMove(index, index - 1)} title="Move up">▲</button>
          <button style={S.iconBtn(false)} disabled={index === total - 1} onClick={() => onMove(index, index + 1)} title="Move down">▼</button>
          <button style={S.iconBtn(true)}  onClick={() => { if (confirm("Delete this question?")) onRemove(); }}>✕</button>
        </div>
        <span style={{ color: C.textMuted, fontSize: 12 }}>{expanded ? "▲" : "▼"}</span>
      </div>

      {/* Body */}
      {expanded && (
        <div style={S.cardBody}>
          <label style={{ ...S.label, marginTop: 0 }}>Question</label>
          <textarea style={{ ...S.textarea, minHeight: 70 }} value={question.question || ""} onChange={e => onUpdate({ question: e.target.value })} placeholder="Enter question text..." />

          <label style={S.label}>Options — click radio to set correct answer</label>
          {(question.options || ["","","",""]).map((opt, i) => (
            <div key={i} style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 7 }}>
              <input
                type="radio"
                name={`q-${question._tempId}-correct`}
                checked={question.correctAnswer === i}
                onChange={() => onUpdate({ correctAnswer: i })}
                style={{ accentColor: C.hunterGreen, width: 16, height: 16, flexShrink: 0, cursor: "pointer" }}
              />
              <span style={{
                width: 22, height: 22, borderRadius: "50%", flexShrink: 0,
                background: question.correctAnswer === i ? C.hunterGreen : C.borderLight,
                color: question.correctAnswer === i ? "#fff" : C.textMuted,
                display: "flex", alignItems: "center", justifyContent: "center",
                fontSize: 11, fontWeight: 700,
              }}>
                {["A","B","C","D"][i]}
              </span>
              <input
                style={{ ...S.input, flex: 1, background: question.correctAnswer === i ? "#F0FDF4" : C.stone, borderColor: question.correctAnswer === i ? C.hunterGreen : C.border }}
                value={opt}
                placeholder={`Option ${["A","B","C","D"][i]}`}
                onChange={e => { const options = [...(question.options || ["","","",""])]; options[i] = e.target.value; onUpdate({ options }); }}
              />
            </div>
          ))}

          <label style={S.label}>Explanation (shown after answering)</label>
          <textarea style={{ ...S.textarea, minHeight: 60 }} value={question.explanation || ""} onChange={e => onUpdate({ explanation: e.target.value })} placeholder="Why is this the correct answer?" />
        </div>
      )}
    </div>
  );
}

// ─── Main tab ─────────────────────────────────────────────────────────────────

export default function AssessmentTab() {
  const {
    state,
    addAssessmentQ, updateAssessmentQ, removeAssessmentQ, moveAssessmentQ,
    setAssessmentMeta,
  } = useCourseBuilder();

  const questions = state.assessment?.questions || [];
  const passing   = state.assessment?.passingScore ?? 80;
  const attempts  = state.assessment?.maxAttempts  ?? 3;
  const minQ      = ACEP_RULES.MIN_ASSESSMENT_QUESTIONS;
  const remaining = Math.max(0, minQ - questions.length);

  // moveAssessmentQ may not be in context — use dispatch directly if needed
  const { dispatch } = useCourseBuilder();
  function moveQ(from, to) {
    if (to < 0 || to >= questions.length) return;
    import("../courseBuilderReducer.js").then(({ A }) => {
      dispatch({ type: A.MOVE_ASSESSMENT_Q, from, to });
    });
  }

  return (
    <div style={{ maxWidth: 820, margin: "0 auto" }}>

      {/* ── Stats bar ── */}
      <div style={{ display: "flex", gap: 16, marginBottom: 20, flexWrap: "wrap" }}>
        <div style={{ background: "#fff", border: `1px solid ${C.border}`, borderRadius: 10, padding: "12px 20px", flex: 1, minWidth: 120 }}>
          <div style={{ fontSize: 28, fontWeight: 800, color: questions.length >= minQ ? C.hunterGreen : C.danger }}>{questions.length}</div>
          <div style={{ fontSize: 12, color: C.textMuted }}>Questions (min {minQ})</div>
        </div>
        <div style={{ background: "#fff", border: `1px solid ${C.border}`, borderRadius: 10, padding: "12px 20px", flex: 1, minWidth: 120 }}>
          <div style={{ fontSize: 28, fontWeight: 800, color: C.navy }}>{passing}%</div>
          <div style={{ fontSize: 12, color: C.textMuted }}>Passing Score</div>
        </div>
        <div style={{ background: "#fff", border: `1px solid ${C.border}`, borderRadius: 10, padding: "12px 20px", flex: 1, minWidth: 120 }}>
          <div style={{ fontSize: 28, fontWeight: 800, color: C.navy }}>{attempts}</div>
          <div style={{ fontSize: 12, color: C.textMuted }}>Max Attempts</div>
        </div>
        {remaining > 0 && (
          <div style={{ background: "#FEF3C7", border: `1px solid #FDE68A`, borderRadius: 10, padding: "12px 20px", flex: 1, minWidth: 180 }}>
            <div style={{ fontSize: 13, fontWeight: 700, color: "#92400E" }}>⚠️ {remaining} more question{remaining !== 1 ? "s" : ""} needed</div>
            <div style={{ fontSize: 11, color: "#92400E", marginTop: 2 }}>NBCC ACEP requires at least {minQ}</div>
          </div>
        )}
      </div>

      {/* ── Settings ── */}
      <div style={{ background: "#fff", border: `1px solid ${C.border}`, borderRadius: 10, padding: 20, marginBottom: 20 }}>
        <div style={{ fontSize: 13, fontWeight: 700, color: C.navy, marginBottom: 12 }}>Exam Settings</div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
          <div>
            <label style={{ ...S.label, marginTop: 0 }}>Passing Score (%)</label>
            <input type="number" min="50" max="100" style={S.input}
              value={passing}
              onChange={e => setAssessmentMeta({ passingScore: Number(e.target.value), passThreshold: Number(e.target.value) / 100 })}
            />
          </div>
          <div>
            <label style={{ ...S.label, marginTop: 0 }}>Max Attempts</label>
            <select style={{ ...S.input, cursor: "pointer" }} value={attempts} onChange={e => setAssessmentMeta({ maxAttempts: Number(e.target.value) })}>
              {[1,2,3,4,5].map(n => <option key={n} value={n}>{n}</option>)}
            </select>
          </div>
        </div>
      </div>

      {/* ── Distribution chart ── */}
      <DistributionChart questions={questions} />

      {/* ── Question list ── */}
      {questions.map((q, qi) => (
        <QuestionCard
          key={q._tempId || qi}
          question={q}
          index={qi}
          total={questions.length}
          onUpdate={updates => updateAssessmentQ(qi, updates)}
          onRemove={() => removeAssessmentQ(qi)}
          onMove={moveQ}
        />
      ))}

      {/* ── Empty state ── */}
      {questions.length === 0 && (
        <div style={{ textAlign: "center", padding: 60, color: C.textMuted, border: `2px dashed ${C.border}`, borderRadius: 12, marginBottom: 16 }}>
          <div style={{ fontSize: 32, marginBottom: 8 }}>📋</div>
          <p style={{ fontSize: 14, fontWeight: 600, marginBottom: 4 }}>No exam questions yet</p>
          <p style={{ fontSize: 12 }}>Add at least {minQ} questions for NBCC ACEP compliance.</p>
        </div>
      )}

      {/* ── Add question ── */}
      <button style={{ ...S.btn("primary"), width: "100%", padding: "12px" }}
        onClick={() => addAssessmentQ()}>
        + Add Question
      </button>

    </div>
  );
}
