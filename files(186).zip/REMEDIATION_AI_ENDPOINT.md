# Remediation AI Inference — Deployment & Usage
**Date:** April 24, 2026
**Feature:** Adaptive Remediation — AI inference endpoint
**Depends on:** RemediationSchema (deployed), CReady Viewer patch (deployed)

---

## Files in this package

| File | Goes to | Purpose |
|------|---------|---------|
| `remediationInference.js` | `server/src/services/remediationInference.js` | Core logic — pure, testable |
| `remediation.js` | `server/src/routes/remediation.js` | Express routes (admin-only) |
| `runRemediation.js` | `server/src/scripts/runRemediation.js` | CLI wrapper for Render shell |

Create these as three new files. No existing files are modified *except* `index.js` to register the route (one line, below).

---

## Step 1 — Upload the three files

Drop them into the paths above via GitHub web editor.

---

## Step 2 — Register the route in `server/src/index.js`

Near your other `app.use('/api/...')` lines (same place where `courseBuilderRoutes` is registered), add:

```js
import remediationRoutes from './routes/remediation.js';
// ...
app.use('/api/remediation', remediationRoutes);
```

---

## Step 3 — Verify middleware import paths

The route file imports:
```js
import { requireAuth } from '../middleware/auth.js';
import { requireAdmin } from '../middleware/admin.js';
```

If your project puts these elsewhere (common variants: `../middleware/authMiddleware.js`, `../middleware/adminAuth.js`, or merged into a single file), edit the imports in `remediation.js` to match. Grep check before deploy:

```bash
grep -rn "export.*requireAuth\|export.*requireAdmin" server/src/middleware/
```

---

## Step 4 — Confirm env vars on Render

The service reads `process.env.ANTHROPIC_API_KEY`. In your Render dashboard → backend service → Environment, confirm it's set. If not:

1. Render → backend service → Environment → Add Environment Variable
2. Key: `ANTHROPIC_API_KEY`, Value: (your Anthropic API key)
3. Save → auto-redeploys

---

## Step 5 — Verify dependencies

The service imports `@anthropic-ai/sdk`. If you're already using the Anthropic API for certificate scanning, it's installed. Quick check:

```bash
cd server && cat package.json | grep anthropic
```

If missing:
```bash
npm install @anthropic-ai/sdk
git add package.json package-lock.json
git commit -m "Add @anthropic-ai/sdk for remediation inference"
git push
```

---

## Step 6 — Deploy and smoke test

Push the three new files + the index.js route registration. Render auto-deploys.

### Smoke test #1 — Route reachable
```bash
curl -X GET https://api.counselorready.com/api/remediation/preview/SOME_COURSE_ID \
  -H "Authorization: Bearer YOUR_ADMIN_TOKEN"
```
Expect: 200 with stats JSON, OR 404 if course doesn't exist, OR 401 if token is bad.
If you get 404 on `/api/remediation/*` (not the course) — the route isn't registered. Revisit Step 2.

### Smoke test #2 — Dry run from Render shell
This is the recommended workflow — no HTTP, no token, direct DB access.

In Render → backend service → Shell:
```bash
cd server
node
```
Then in the Node REPL:
```js
const { run } = await import('./src/scripts/runRemediation.js');

// Pick a small course first — dry run shows what WOULD happen
await run({ slug: 'ethics-and-professional-boundaries', dryRun: true });
```

Expected output: per-KC log like `[high] Introduction / crblk_abc123 → crblk_xyz789 — Block directly teaches dual relationships`, plus summary stats.

### Smoke test #3 — Apply for real on ONE course
```js
await run({ slug: 'ethics-and-professional-boundaries' });
```

Then open that course in the viewer, answer a KC incorrectly, and confirm the "📖 Review this content" button appears. Click it → jumps to the inferred block.

---

## Usage patterns

### Preview a single course (no write)
```js
await run({ slug: 'my-course-slug', dryRun: true });
```

### Apply inference to a single course
```js
await run({ slug: 'my-course-slug' });
```

### Force re-run on a course (overwriting prior AI inferences)
```js
await run({ slug: 'my-course-slug', overwriteAI: true });
```
Note: manual entries (`source: 'manual'`) are NEVER overwritten, even with this flag.

### Backfill all 57 courses at once — preview first
```js
await run({ all: true, dryRun: true });
```
This prints per-course stats + an aggregate at the end. At ~20 KCs per course × 57 courses = ~1,140 Claude Haiku calls, this takes roughly 12-20 minutes depending on API latency and costs around $5-7 total.

### Backfill all 57 courses — apply
```js
await run({ all: true });
```

### HTTP endpoints (for admin UI wiring later)
```
POST /api/remediation/infer/:courseId       { overwriteAI?, dryRun? }
POST /api/remediation/infer-by-slug/:slug   { overwriteAI?, dryRun? }
GET  /api/remediation/preview/:courseId     ?overwriteAI=true
```
All require admin bearer token.

---

## What the service does

For each course:
1. **Assigns stable string IDs** to every content block in every section that doesn't already have one. This is a prerequisite for remediation targeting. Idempotent — existing IDs preserved.
2. For each section, collects:
   - **Candidates** = text / imageText / accordion blocks with ≥40 chars of content
   - **KCs** = multipleChoice / multiSelect / matching blocks
3. For each KC:
   - **Skip** if `remediation.source === 'manual'` (your edits are sacred)
   - **Skip** if `remediation.source === 'ai'` and `overwriteAI: false`
   - Otherwise: send KC + candidate list to Claude Haiku 4.5
   - Parse JSON response: `{ blockId, confidence, reasoning }`
   - Write to `kc.remediation` with `source: 'ai'`
4. Save the course (unless `dryRun: true`)

Per-KC duration: ~0.5-1.5 seconds. Per-course duration: ~15-45 seconds depending on KC count.

---

## Safety guarantees

- **Manual edits are never overwritten.** If you've manually set a remediation target in CourseBuilder (future), AI won't touch it.
- **Same-section targeting only.** Claude is never given candidates from other sections, so it cannot suggest cross-section jumps.
- **Validated responses.** If Claude returns an unknown `blockId` or malformed JSON, that KC is counted as an error and left untouched.
- **Dry run available.** Nothing writes to Mongo unless `dryRun: false` (default). Every change is logged in the `updates` array for audit.
- **Idempotent.** Run it twice, get the same result. Existing AI inferences are skipped on re-run unless `overwriteAI: true`.

---

## Cost estimate

- Model: Claude Haiku 4.5 (`claude-haiku-4-5-20251001`)
- Per KC: ~2,000 input tokens + ~150 output tokens
- At Haiku pricing, roughly **$0.005 per KC**, or about **$0.10 per course**
- Backfilling all 57 courses: **~$5-7 total**

Dry runs cost the same as real runs (they still call the API — they just don't write the result).

---

## Troubleshooting

| Symptom | Likely cause | Fix |
|---------|-------------|-----|
| `ANTHROPIC_API_KEY is not set` | env var missing on Render | Step 4 |
| `404 on /api/remediation/*` | route not registered | Step 2 |
| `Cannot find module '../middleware/auth.js'` | middleware path mismatch | Step 3 |
| `Claude returned unknown blockId` | model hallucination — rare | Logged as error, KC untouched. Re-run with `overwriteAI: true` usually resolves. |
| `No candidate text blocks in section` | section has no text/imageText/accordion blocks | Expected — section literally has nothing to link back to. Consider restructuring the course. |
| Inference produces low-confidence matches | KC question may not match any candidate well | Review candidates via `dryRun: true`; consider manually setting remediation via CourseBuilder (future) or editing the KC to be more specific |

---

## Rollback

If something goes wrong:
1. The service only writes to the `remediation` sub-field on KC blocks. Remove that field from affected courses to revert:
   ```js
   db.interactivecourses.updateMany(
     {},
     { $unset: { 'sections.$[].contentBlocks.$[].remediation': '' } }
   )
   ```
2. The three service files can be deleted (and the `app.use` line in `index.js` removed) with no impact on anything else — they're fully isolated.

---

## What ships next

1. **CourseBuilder editor UI** — dropdowns in `MCBlockEditor` / `MultiSelectEditor` / `MatchingEditor` so you can manually set or tweak remediation targets per KC. Shows existing AI inferences with a confidence badge; "✓ Approve" or "✎ Change" buttons. When you save a manual edit, `source` flips from `'ai'` to `'manual'` and AI won't touch it on future runs.
2. **Admin dashboard summary** — in `admin-courses.html`, add a column/stat showing remediation coverage per course (e.g., "18/22 KCs, 12 high / 5 medium / 1 low / 4 missing") with a one-click "Infer with AI" button that hits the endpoint.

Ping when you've run this on a pilot course and I'll queue up the CourseBuilder UI.
